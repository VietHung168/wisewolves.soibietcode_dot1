	//points
	// NOTE: UNLESS CREATE THEN INSERT, id wont auto create
	#pragma once
	#include <string.h>
	#include "structure.h"
	#include "vectors.h"
	
	//count
	int id_points(point_node *&first){
		point_node *tmp=first;
		int s;
		if(first==NULL){
			s=1000;
			return s;
		}
		else {
		while(tmp->next!=NULL){
			tmp=tmp->next;
		}
		s = tmp->data.id;
		return s;
		}
	}
	
	//create:
	point create_new_point(int x, int y, char name[],point_node *&first){
		point p;
//		cout<<"Input name: ";
//		std::cin>>p.name;
//		cout<<"X: ";
//		std::cin>>p.x;
//		cout<<"Y: ";
//		std::cin>>p.y;
//		cout<<"ID: ";
		p.x = x;
		p.y = y;
		strcpy(p.name, name);
		p.id=1+id_points(first);
		return p;
	}
	
	point_node *create_new_pnode(point p){
		point_node *nodes = new point_node;
		nodes->data=p;
		nodes->next=NULL;
		return nodes;
	}
	
	//insert:

	void insert_last_p(point_node *&first,point p){
		point_node *tmp=create_new_pnode(p);
		if(first==NULL){
			first=tmp;
		}
		else{
			point_node *run=first;
			while(1){
				if(run->next==NULL){
					run->next=tmp;
					break;
				}
				run=run->next;
			}
		}
	}
//	
//	void insert_after_p(point_node *&first,point p){
//		point_node *tmp=create_new_pnode(p);
//		if(first==NULL){
//			first==tmp;
//			return;
//		}
//		if(tmp->data.id<first->data.id){
//			insert_first_p(first,p);
//		}
//		else {
//			point_node *run=first;
//			while(run->next!=NULL){
//				if(run->next->data.id > tmp->data.id){
//					tmp->next = run->next;
//					run->next = tmp;
//					return;
//				}
//				run=run->next;
//			}
//			insert_last_p(first, students);
//		}
//		
//	}
//	

	//search -> find and replace
	point search_pid(point_node *first,int pid){
		point_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.id==pid){
				point p=tmp->data;
				return p;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT point's ID"<<std::endl;
	}
	
	void edit_pid(point_node *first,int pid,char name[20]){
		point_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.id==pid){
				strcpy(tmp->data.name,name);
				return;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT point's ID"<<std::endl;
	}
	
	//delete
	void delete_pid(point_node *&firstp,vector_node *&firstv,int pid){
		if(firstp==NULL) return;
		point_node *tmp = firstp;
		point_node *node_del;
		bool run=true;
		if(tmp->data.id==pid) {
			node_del=tmp;
			firstp=tmp->next;
			//delete vector has start or end is point had deleted
//			vector_node *tmpv=firstv;
//			vector_node *delv;
			point data=node_del->data;
			while(run==true && firstv!=NULL){
				delete_vectorbyPoint(firstv,data,run);
//				if(firstv!=NULL){
//					tmpv=firstv;
//				}
			}
			delete node_del;
			return;
		}
		if(tmp->next==NULL) return;
		while(1){
			if(tmp->next->data.id==pid){
				node_del = tmp->next;
				tmp->next=node_del->next;
//				vector_node *tmpv=firstv;
//				vector_node *delv;
				point data=node_del->data;
				while(run==true && firstv!=NULL){
					delete_vectorbyPoint(firstv,data,run);
//					if(firstv!=NULL){
//						tmpv=firstv;
//					}				
				}
				delete node_del;
				return;
			}
			tmp=tmp->next;
			if(tmp->next==NULL) break;
		}
//		std::cout<<"ERROR CAN'T FIND POINT TO DELETE"<<std::endl;
	}
