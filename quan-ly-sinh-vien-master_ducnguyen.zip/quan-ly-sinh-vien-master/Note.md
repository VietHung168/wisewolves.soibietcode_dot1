Những thứ chưa tốt sau báo cáo chưa fix (sẽ được fix dần):
- Lớp tín chỉ nên sửa lại mã lớp tín chỉ trong file cho tăng dần, và thay đổi thuật toán sinh mã lớp tự động ko trùng cho nhanh nhất
- Filter ở phần xuất ds lớp tin chỉ nên cho tìm kiếm bằng tên môn học thay vì mã lớp tin chỉ (người dùng không nhớ mã lớp)
- Lớp tín chỉ có 4 khóa chính, mã môn học, khóa, học kỳ, nhóm, khi thông báo nhập bị trùng thì phải chỉ rõ là trùng khóa nào
- Không cho sinh viên đăng ký vào lớp tín chỉ sau khi nhập/sửa điểm của lớp
- Xuất danh sách sinh viên nên cho tìm theo họ tên
- Xuất danh sách đăng ký nên cho chọn lớp tín chỉ
- Phần tìm nhập điểm sinh viên theo form chưa cập nhật được điểm sửa tạm thời khi nhập/sửa điểm theo trang
- 1 lớp tín chỉ nếu chưa nhập điểm, chưa bị hủy thì có thể cho sinh viên đã đăng ký hủy đăng ký lớp đó