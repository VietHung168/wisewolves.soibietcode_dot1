	#pragma once
	#include "points.h"
	#include <cmath>
	#include "matrix.h"
	#include "draw.h"
	
	void outWrapTextXY(int x, int y, int soKyTuTrenMotHang, int khoangCachGiuaHang, char s[]){
	int len = strlen(s);
	
	int sPos = 0;
	int cSpace = 0;
	int countLineChar = 0;
	int rowCount = 0;
	while(sPos<len){
		if(s[sPos]==' '){
			cSpace=sPos;
		}
		sPos++;
		countLineChar++;
		if(countLineChar==soKyTuTrenMotHang){
			countLineChar=0;
			sPos=cSpace+1;
			rowCount++;
		}
	}
	
	if(countLineChar>0) rowCount++;
	
	sPos = 0;
	cSpace = 0;
	countLineChar = 0;
	char **charList = new char*[rowCount];
	int i = 0;
	int startPosition = 0;
	while(sPos<len){
		if(s[sPos]==' '){
			cSpace=sPos;
		}
		sPos++;
		countLineChar++;
		if(countLineChar==soKyTuTrenMotHang){
			countLineChar=0;
			charList[i] = new char[soKyTuTrenMotHang+1];
			strncpy(charList[i], &s[startPosition], cSpace-startPosition);
			charList[i][cSpace-startPosition]=0;
			sPos=cSpace+1;
			startPosition=sPos;
			i++;
		}
	}
	
	if(countLineChar>0){
		charList[i] = new char[soKyTuTrenMotHang+1];
		strncpy(charList[i], &s[startPosition], len-startPosition);
		charList[i][len-startPosition]=0;
	}
	
	for(int i=0; i<rowCount; i++){
		outtextxy(x, y+(i*khoangCachGiuaHang), charList[i]);
	}
	
}
	
	char* StripSpaces(char input[]){
    	char* output = new char[20];
    	int i = 0, j = 0;
        
    	while (input[i] != '\0'){
        	if (input[i] != ' '){
				output[j] = input[i];
			}
			else j--;

			i++; j++;
    	}

    	return output;	
	}
	
	void convertToCharArray(char s[], int n){
		char c[100];
		int i=0;
		while(n>0){
			c[i] = (n%10)+'0';
			n=n/10;
			i++;
		}
		c[i]='\0';
		int len = 0;
		i--;
		while(len<=i){
			s[len] = c[i-len];
			len++;
		}
		s[len]='\0';
	}
	
	int convertToInt(char s[]){
		int n=0;
		for(int i=0; i<strlen(s); i++){
			n=n*10+(s[i]-'0');
		}
		return n;
	}
	
	//	//graphic
	void reset_map_id(int **map_id){
		for(int i=0;i<1600;i++){
			for (int j=0;j<900;j++){
				map_id[i][j]=-1;
			}
		}
	}
	
	void reset_btnsub_id(int **map_id){
		for(int i=150;i<300;i++){
			for (int j=0;j<600;j++){
				map_id[i][j]=-1;
			}
		}
	}
	
	void set_draw_area_id(int **map_id){
		for(int i=300;i<1600;i++){
			for (int j=0;j<750;j++){
				map_id[i][j]=9999;
			}
		}
	}

	void reset_draw_area_id(int **map_id){
		for(int i=300;i<1600;i++){
			for (int j=0;j<750;j++){
				map_id[i][j]=-1;
			}
		}
	}
	
	void set_id(int **map_id,int x1, int y1,int x2,int y2,int id){
		for(int i=x1;i<x2;i++){
			for(int j=y1;j<y2;j++){
				map_id[i][j]=id;
			}
		}
	}
	
	void set_vertex_id(int **map_id,point p){
		for(int i=p.x-15;i<p.x+15;i++){
			for(int j=p.y-15;j<p.y+15;j++){
				map_id[i][j]=p.id;
			}
		}
	}
	
	void create_btn(int **map_id,int x1,int y1, int x2,int y2,int id, char text[]){
		setbkcolor(15);
		setfillstyle(1,15);
		settextstyle(0,0,2);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		outtextxy(x1+(x2-x1)/2,y1+(y2-y1)/2,text);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_btn_focus(int **map_id,int x1,int y1, int x2,int y2,int id, char text[]){
		setbkcolor(2);
		setfillstyle(1,2);
		settextstyle(0,0,2);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		setcolor(15);
		outtextxy(x1+(x2-x1)/2,y1+(y2-y1)/2,text);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_subbtn(int **map_id,int x1,int y1, int x2,int y2,int id, char text[]){
		setbkcolor(15);
		setfillstyle(1,15);
		settextstyle(0,0,-4);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		outtextxy(x1+(x2-x1)/2,y1+(y2-y1)/2,text);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_subbtn_focus(int **map_id,int x1,int y1, int x2,int y2,int id, char text[]){
		setbkcolor(10);
		setfillstyle(1,10);
		settextstyle(0,0,-4);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		outtextxy(x1+(x2-x1)/2,y1+(y2-y1)/2,text);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_subbtn_db(int **map_id,int x1,int y1, int x2,int y2,int id, char text[],char text2[]){
		setbkcolor(15);
		setfillstyle(1,15);
		settextstyle(0,0,-4);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		outtextxy(x1+(x2-x1)/2,(y1+(y2-y1)/2)-5,text);
		outtextxy(x1+(x2-x1)/2,(y1+(y2-y1)/2)+10,text2);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_subbtn_db_focus(int **map_id,int x1,int y1, int x2,int y2,int id, char text[],char text2[]){
		setbkcolor(10);
		setfillstyle(1,10);
		settextstyle(0,0,-4);
		settextjustify(1,1);
		setcolor(0);
		bar(x1,y1,x2,y2);
		rectangle(x1,y1,x2,y2);
		outtextxy(x1+(x2-x1)/2,(y1+(y2-y1)/2)-5,text);
		outtextxy(x1+(x2-x1)/2,(y1+(y2-y1)/2)+10,text2);
		set_id(map_id,x1,y1,x2,y2,id);
	}
	
	void create_menu_bar(int **map_id,bool VN){
		setbkcolor(15);
		setfillstyle(1,15);
		setcolor(0);
		bar(0,0,300,600);
		rectangle(0,0,300,600);
		bar(0,600,300,900);
		rectangle(0,600,300,900);
		bar(300,750,1600,900);
		rectangle(300,750,1600,900);
//		rectangle(950,750,1600,900);
		settextstyle(0,0,2);
		settextjustify(1,2);
		setcolor(4);
		if(VN){
			outtextxy(150,610,"MA TRAN");
			outtextxy(950,760,"KET QUA");
		}
		else{
			outtextxy(150,610,"MATRIX");
			outtextxy(950,760,"RESULT");
		}
	}
	
	void reset_Result_area(){
		setbkcolor(15);
		setfillstyle(1,15);
		setcolor(0);
		bar(300,750,1600,900);
		rectangle(300,750,1600,900);
		setcolor(4);
		settextstyle(0,0,2);
		settextjustify(1,2);
		outtextxy(950,760,"RESULT");
	}
	
//	void note_Demo(){
//		setbkcolor(15);
//		setcolor(4);
//		settextstyle(2,0,5);
//		settextjustify(1,2);
////		outtextxy(625,760,"RESULT");
//		outtextxy(440,755,"Up:Speed up | Down: Speed down | Esc: End demo");
//	}

	void draw_point_groupcolor(point p,int textcolor,int fillcolor, int sidecolor){
		setbkcolor(fillcolor);
		setfillstyle(1,fillcolor);
		setcolor(sidecolor);
		settextstyle(0,0,2);
		settextjustify(1,1);
		fillellipse(p.x,p.y,15,15);
		circle(p.x,p.y,15);
		setcolor(textcolor);
		outtextxy(p.x,p.y+2,p.name);
	}
	
	void draw_point_wait(point p){
		setbkcolor(14);
		setfillstyle(1,14);
		setcolor(0);
		settextstyle(0,0,2);
		settextjustify(1,1);
		fillellipse(p.x,p.y,15,15);
		circle(p.x,p.y,15);
		setcolor(3);
		outtextxy(p.x,p.y+2,p.name);
	}
	
	void draw_point_source(point p){
		setbkcolor(12);
		setfillstyle(1,12);
		setcolor(0);
		settextstyle(0,0,2);
		settextjustify(1,1);
		fillellipse(p.x,p.y,15,15);
		circle(p.x,p.y,15);
		setcolor(14);
		outtextxy(p.x,p.y+2,p.name);
	}
	
	void draw_point_received(point p){
		setbkcolor(10);
		setfillstyle(1,10);
		setcolor(0);
		settextstyle(0,0,2);
		settextjustify(1,1);
		fillellipse(p.x,p.y,15,15);
		circle(p.x,p.y,15);
		setcolor(14);
		outtextxy(p.x,p.y+2,p.name);
	}
	
	void draw_point(point p){
		setbkcolor(15);
		setfillstyle(1,15);
		setcolor(0);
		settextstyle(0,0,2);
		settextjustify(1,1);
		fillellipse(p.x,p.y,15,15);
		circle(p.x,p.y,15);
		outtextxy(p.x,p.y+2,p.name);
	}
	
	void create_point(int **map_id,point p){
		draw_point(p);
		set_vertex_id(map_id,p);
	}
	
	// tinh ptrinh + ve mui ten
	int giaiPT(float a, float b, float c,float &x1, float &x2){
    float delta = b*b - 4*a*c;
    if(delta<0){
        x1=x2=0.0;
        return 0;
    }
    else if(delta==0){
        x1 = x2 = -b/(2*a);
        return 1;
    }
    else{
        delta = sqrt(delta);
        x1 = (-b + delta) / (2*a);
        x2 = (-b - delta) / (2*a);
        return 2;
    }
}

void lineWithValue(int x1, int y1, int x2, int y2, int value){
	line(x1, y1, x2, y2);
	char tmpValue[5];
	setbkcolor(11);
	settextstyle(2, 0, 5);
	settextjustify(0, 0);
	convertToCharArray(tmpValue, value);
//	outtextxy((x1+x2)/2, (y1+y2)/2-10,"  ");
	outtextxy((x1+x2)/2, (y1+y2)/2-10,tmpValue);


	float xab = (float) x2-x1;
	float yab = (float) y2-y1;
	
	if(xab==0 && y2<=y1){
		line(x2-10, y2+25, x2, y2-15);
		line(x2+10, y2+25, x2, y2-15);
		return;
	}
	else if(xab==0 && y2>=y1){
		line(x2-10, y2-25, x2, y2+15);
		line(x2+10, y2-25, x2, y2+15);
		return;
	}
	else if(yab==0 && x2<=x1){
		line(x2+25, y2-10, x2+15, y2);
		line(x2+25, y2+10, x2+15, y2);
		return;
	}
	else if(yab==0 && x2>=x1){
		line(x2-25, y2-10, x2-15, y2);
		line(x2-25, y2+10, x2-15, y2);
		return;
	}
	
	float xn = -yab;
	float yn = xab;
	//Phuong trinh duong thang line
	float a = xn;
	float b = yn;
	//ax+by+c=0  |  c = 0 - ax - by  |  y = (-ax - c)/b
	float c = - a*x1 - b*y1;
	
	//Phuong trinh duong tron tam x2, y2, ban kinh 20
	//(x-a)^2 + (y-b)^2 = r^2
	//(x^2 - 2xa + a^2) + (y^2 - 2yb + b^2) = r^2
	//x^2 + y^2 - 2ax - 2by + a^2 + b^2 - r^2 = 0
	//x^2 + y^2 - 2.x2.x - 2.y2.y + x2^2 + y2^2 - r^2 = 0
//	circle(x2,y2,20);
	
	//Tim diem giao cua line v� duong tron
	//x^2 + ((-ax - c)/b)^2 - 2.x2.x - 2.y2.(-ax - c)/b + x2^2 + y2^2 - r^2 = 0
	//x^2 + ((-ax-c)^2 / b^2) - 2.x2.x + (-2.y2.(-a.x-c))/b + x2^2 + y2^2 - r^2 = 0
	//x^2 + ((-a)^2.x^2 - 2(-axc) + c^2)/b^2 - 2.x2.x + (2.y2.a.x + 2.y2.c)/b + x2^2 + y2^2 - r^2 = 0
	//(b^2+a^2)x^2 + (2.a.c-2.b^2.x2+2.b.y2.a)x + (c^2+2.b.y2.c+b^2(x2^2+y2^2-r^2)) = 0
	//Giai tim nghiem xd va lay xd sao cho (xd>x1 && xd<x2) || (xd<x1 && xd>x2)
	float xd, xd1, xd2;
	int typeResult = giaiPT(b*b+a*a, (float)2*a*c - (float)2*b*b*x2 + (float)2*b*y2*a, c*c + (float)2*b*y2*c + (float)(b*b)*(x2*x2 + y2*y2 - 15*15), xd1, xd2);
//	std::cout<<"type: "<<typeResult<<std::endl;
	if(x1<=x2){
		if(xd1>=x1 && xd1<=x2){
			xd = xd1;
		}
		else{
			xd = xd2;
		}
	}
	else{
		if(xd1<=x1 && xd1>=x2){
			xd = xd1;
		}
		else{
			xd = xd2;
		}
	}
	
	float yd = (-a*xd - c)/b;
	
	
	float xdd, xdd1, xdd2;
	giaiPT(b*b+a*a, (float)2*a*c - (float)2*b*b*xd + (float)2*b*yd*a, c*c + (float)2*b*yd*c + (float)(b*b)*(xd*xd + yd*yd - 20*20), xdd1, xdd2);
//	std::cout<<"type: "<<typeResult<<std::endl;
	if(x1<=x2){
		if(xdd1>=x1 && xdd1<=x2){
			xdd = xdd1;
		}
		else{
			xdd= xdd2;
		}
	}
	else{
		if(xdd1<=x1 && xdd1>=x2){
			xdd = xdd1;
		}
		else{
			xdd = xdd2;
		}
	}
//	std::cout<<"xd1: "<<xd1<<" - xd2: "<<xd2<<std::endl;
		
	//Thay xd vao phuong trinh duong thang line de tim yd
	float ydd = (-a*xdd - c)/b;
//	std::cout<<"a: "<<a<<" b: "<<b<<" c: "<<c<<std::endl;
//	std::cout<<"xd: "<<xd<<" - yd: "<<yd<<std::endl;
	
	//tim phuong trinh duong thang d di qua (xd, yd) vuong goc voi line
	//VTCP line (a,b) la VTPT cua d
	float ad = -b;
	float bd = a;
	//ad(x-x0)+bd(y-y0)=0
	//ad.x-ad.x0 + bd.y-bd.y0 = 0
	//ad.x + bd.y - ad.x0 - bd.y0 = 0
	float cd = - ad*xd - bd*yd;
	float cdd = - ad*xdd - bd*ydd;
	
	//tim giao diem lineD voi duong tron
	//tuong tu
	giaiPT(bd*bd+ad*ad, (float)2*ad*cdd - (float)2*bd*bd*xd + (float)2*bd*yd*ad, cdd*cdd + (float)2*bd*yd*cdd + (float)(bd*bd)*(xd*xd + yd*yd - 25*25), xd1, xd2);
	float yd1 = (-ad*xd1 - cdd)/bd;
	float yd2 = (-ad*xd2 - cdd)/bd;
	
	line(xd1, yd1, xd, yd);
	line(xd2, yd2, xd, yd);
}

	void drawLineWithValue(int x1, int y1, int x2, int y2, int value){
		setcolor(0);
		lineWithValue(x1,y1,x2,y2,value);
	}

	void drawLineWithValueRun(int x1, int y1, int x2, int y2, int value){
		setcolor(4);
		setlinestyle(0,0,3);
		lineWithValue(x1,y1,x2,y2,value);
		setlinestyle(0,0,1);
	}

void lineNoValue(int x1, int y1, int x2, int y2){
	line(x1, y1, x2, y2);
//	char tmpValue[5];
	setbkcolor(11);
	settextstyle(2, 0, 5);
	settextjustify(0, 0);
//	convertToCharArray(tmpValue, value);
//	outtextxy((x1+x2)/2, (y1+y2)/2-10,"  ");
//	outtextxy((x1+x2)/2, (y1+y2)/2-10,tmpValue);


	float xab = (float) x2-x1;
	float yab = (float) y2-y1;
	
	if(xab==0 && y2<=y1){
		line(x2-10, y2+25, x2, y2-15);
		line(x2+10, y2+25, x2, y2-15);
		return;
	}
	else if(xab==0 && y2>=y1){
		line(x2-10, y2-25, x2, y2+15);
		line(x2+10, y2-25, x2, y2+15);
		return;
	}
	else if(yab==0 && x2<=x1){
		line(x2+25, y2-10, x2+15, y2);
		line(x2+25, y2+10, x2+15, y2);
		return;
	}
	else if(yab==0 && x2>=x1){
		line(x2-25, y2-10, x2-15, y2);
		line(x2-25, y2+10, x2-15, y2);
		return;
	}
	
	float xn = -yab;
	float yn = xab;
	//Phuong trinh duong thang line
	float a = xn;
	float b = yn;
	//ax+by+c=0  |  c = 0 - ax - by  |  y = (-ax - c)/b
	float c = - a*x1 - b*y1;
	
	//Phuong trinh duong tron tam x2, y2, ban kinh 20
	//(x-a)^2 + (y-b)^2 = r^2
	//(x^2 - 2xa + a^2) + (y^2 - 2yb + b^2) = r^2
	//x^2 + y^2 - 2ax - 2by + a^2 + b^2 - r^2 = 0
	//x^2 + y^2 - 2.x2.x - 2.y2.y + x2^2 + y2^2 - r^2 = 0
//	circle(x2,y2,20);
	
	//Tim diem giao cua line v� duong tron
	//x^2 + ((-ax - c)/b)^2 - 2.x2.x - 2.y2.(-ax - c)/b + x2^2 + y2^2 - r^2 = 0
	//x^2 + ((-ax-c)^2 / b^2) - 2.x2.x + (-2.y2.(-a.x-c))/b + x2^2 + y2^2 - r^2 = 0
	//x^2 + ((-a)^2.x^2 - 2(-axc) + c^2)/b^2 - 2.x2.x + (2.y2.a.x + 2.y2.c)/b + x2^2 + y2^2 - r^2 = 0
	//(b^2+a^2)x^2 + (2.a.c-2.b^2.x2+2.b.y2.a)x + (c^2+2.b.y2.c+b^2(x2^2+y2^2-r^2)) = 0
	//Giai tim nghiem xd va lay xd sao cho (xd>x1 && xd<x2) || (xd<x1 && xd>x2)
	float xd, xd1, xd2;
	int typeResult = giaiPT(b*b+a*a, (float)2*a*c - (float)2*b*b*x2 + (float)2*b*y2*a, c*c + (float)2*b*y2*c + (float)(b*b)*(x2*x2 + y2*y2 - 15*15), xd1, xd2);
//	std::cout<<"type: "<<typeResult<<std::endl;
	if(x1<=x2){
		if(xd1>=x1 && xd1<=x2){
			xd = xd1;
		}
		else{
			xd = xd2;
		}
	}
	else{
		if(xd1<=x1 && xd1>=x2){
			xd = xd1;
		}
		else{
			xd = xd2;
		}
	}
	
	float yd = (-a*xd - c)/b;
	
	
	float xdd, xdd1, xdd2;
	giaiPT(b*b+a*a, (float)2*a*c - (float)2*b*b*xd + (float)2*b*yd*a, c*c + (float)2*b*yd*c + (float)(b*b)*(xd*xd + yd*yd - 20*20), xdd1, xdd2);
//	std::cout<<"type: "<<typeResult<<std::endl;
	if(x1<=x2){
		if(xdd1>=x1 && xdd1<=x2){
			xdd = xdd1;
		}
		else{
			xdd= xdd2;
		}
	}
	else{
		if(xdd1<=x1 && xdd1>=x2){
			xdd = xdd1;
		}
		else{
			xdd = xdd2;
		}
	}
//	std::cout<<"xd1: "<<xd1<<" - xd2: "<<xd2<<std::endl;
		
	//Thay xd vao phuong trinh duong thang line de tim yd
	float ydd = (-a*xdd - c)/b;
//	std::cout<<"a: "<<a<<" b: "<<b<<" c: "<<c<<std::endl;
//	std::cout<<"xd: "<<xd<<" - yd: "<<yd<<std::endl;
	
	//tim phuong trinh duong thang d di qua (xd, yd) vuong goc voi line
	//VTCP line (a,b) la VTPT cua d
	float ad = -b;
	float bd = a;
	//ad(x-x0)+bd(y-y0)=0
	//ad.x-ad.x0 + bd.y-bd.y0 = 0
	//ad.x + bd.y - ad.x0 - bd.y0 = 0
	float cd = - ad*xd - bd*yd;
	float cdd = - ad*xdd - bd*ydd;
	
	//tim giao diem lineD voi duong tron
	//tuong tu
	giaiPT(bd*bd+ad*ad, (float)2*ad*cdd - (float)2*bd*bd*xd + (float)2*bd*yd*ad, cdd*cdd + (float)2*bd*yd*cdd + (float)(bd*bd)*(xd*xd + yd*yd - 25*25), xd1, xd2);
	float yd1 = (-ad*xd1 - cdd)/bd;
	float yd2 = (-ad*xd2 - cdd)/bd;
	
	line(xd1, yd1, xd, yd);
	line(xd2, yd2, xd, yd);
}

void drawLine(int x1,int y1,int x2,int y2){
	setcolor(0);
	lineNoValue(x1,y1,x2,y2);
}

void drawLineRun(int x1,int y1,int x2,int y2){
	setcolor(4);
	setlinestyle(0,0,3);
	lineNoValue(x1,y1,x2,y2);
	setlinestyle(0,0,1);
}

void clearLine(int x1, int y1, int x2, int y2){
	setcolor(11);
	lineNoValue(x1, y1, x2, y2);
}

void setLineID(int **map_id,int x1,int y1,int x2,int y2, int id){
        int x,y,dx,dy,dx1,dy1,px,py,xe,ye,i;
        dx=x2-x1;
        dy=y2-y1;
        dx1=abs(dx);
        dy1=abs(dy);
        px=2*dy1-dx1;
        py=2*dx1-dy1;
        if(dy1<=dx1){
            if(dx>=0){
                x=x1;
                y=y1;
                xe=x2;
            }
            else{
                x=x2;
                y=y2;
                xe=x1;
            }
            map_id[x][y]=id ,map_id[x+1][y+1]=id,map_id[x-1][y-1]=id,map_id[x+2][y+2]=id,map_id[x-2][y-2]=id;
            int k=0, c=1;
            for(i=0;x<xe;i++){
                x=x+1;
                if(px<0){
                    px=px+2*dy1;
                }
                else{
                    if((dx<0 && dy<0) || (dx>0 && dy>0)){
                        y=y+1;
                    }
                    else{
                        y=y-1;
                    }
                    px=px+2*(dy1-dx1);
                }
                
                map_id[x][y]=id ,map_id[x+1][y+1]=id,map_id[x-1][y-1]=id,map_id[x+2][y+2]=id,map_id[x-2][y-2]=id;
                
            }
        }
        else{
            if(dy>=0){
                x=x1;
                y=y1;
                ye=y2;
            }
            else{
                x=x2;
                y=y2;
                ye=y1;
            }
            map_id[x][y]=id;
            int k=0, c=1;
            for(i=0;y<ye;i++){
                y=y+1;
                if(py<=0){
                    py=py+2*dx1;
                }
                else{
                    if((dx<0 && dy<0) || (dx>0 && dy>0)){
                        x=x+1;
                    }
                    else{
                        x=x-1;
                    }
                    py=py+2*(dx1-dy1);
                }
                
                map_id[x][y]=id ,map_id[x+1][y+1]=id,map_id[x-1][y-1]=id,map_id[x+2][y+2]=id,map_id[x-2][y-2]=id;
                
            }
        }
    }
    
    void drawTable(int rows, int cols, int x1, int y1, int x2, int y2, point_node *&pfirst, vector_node *&vfirst){
	setcolor(0);
	
	int dWidth = (x2-x1)/cols;
	int dHeight = (y2-y1)/rows;
	
	for(int i=0; i<rows; i++){
		for(int j=0; j<cols; j++){
			rectangle(x1+(i*dWidth), y1+(j*dHeight), x1+((i+1)*dWidth), y1+((j+1)*dHeight));
		}
	}
	
	settextjustify(0, 2);
	settextstyle(2,0,5);
	
	point_node *ptmp = pfirst;
	int x=1, y=0;
	while(ptmp!=NULL){
		outtextxy(x1+(x*dWidth)+1, y1+(y*dHeight)+1, ptmp->data.name);
		ptmp=ptmp->next;
		x++;
	}
	
	ptmp = pfirst;
	x=0, y=1;
	while(ptmp!=NULL){
		outtextxy(x1+(x*dWidth)+1, y1+(y*dHeight)+1, ptmp->data.name);
		ptmp=ptmp->next;
		y++;
	}
	
	for(int i=1; i<rows; i++){
		for(int j=1; j<cols; j++){
			outtextxy(x1+(i*dWidth)+1, y1+(j*dHeight)+1, "0");
		}
	}
	
	vector_node *vtmp = vfirst;
	while(vtmp!=NULL){
		point pstart=vtmp->data.start;
		point pend=vtmp->data.end;
		int start = ordinal_Number(pfirst,pstart);
		int end = ordinal_Number(pfirst,pend);
		
		char value[5];
		convertToCharArray(value, vtmp->data.l);
		outtextxy(x1+((end)*dWidth)+1, y1+((start)*dHeight)+1, "   ");
		outtextxy(x1+((end)*dWidth)+1, y1+((start)*dHeight)+1, value);
		
		vtmp = vtmp->next;
		
	}
	
}

void drawView(int x1, int y1, int x2, int y2, int fColor, int lColor, int textColor){
	setcolor(lColor);
	setfillstyle(1, fColor);
	bar(x1, y1, x2, y2);
	rectangle(x1, y1, x2, y2);
	setcolor(textColor);
	setbkcolor(fColor);
}


