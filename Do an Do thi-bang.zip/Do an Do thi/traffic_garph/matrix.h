#pragma once
#include "structure.h"
#include "graphic.h"
#include "vectors.h"
#include "points.h"


int countPoint(point_node *&pfirst){
	point_node *ptmp=pfirst;
	int s=0;
	while(ptmp!=NULL){
		s=s+1;
		ptmp=ptmp->next;
	}
	return s;
}

int ordinal_Number(point_node *&pfirst,point p){
	point_node *ptmp=pfirst;
	int s=0;
	while(ptmp!=NULL){
		s=s+1;
		if(ptmp->data.id==p.id){
			return s;
		}
		ptmp=ptmp->next;
	}
}

point findPointByOr(point_node *&pfirst,int orNum){
	point_node *ptmp=pfirst;
	int s=0;
	while(ptmp!=NULL){
		s=s+1;
		if(s==orNum){
			return ptmp->data;
		}
		ptmp=ptmp->next;
	}
}

int **createMatrix_Reverse(point_node *&pfirst,vector_node *&vfirst){
	int **matrix = new int*[countPoint(pfirst)];
	for(int i = 0; i<countPoint(pfirst); i++)
	   matrix[i] = new int[countPoint(pfirst)];
	 
	for(int i=0; i<countPoint(pfirst); i++){
		for(int j=0; j<countPoint(pfirst); j++){
			matrix[i][j]=0;
		}
	}
	  
	vector_node *vtmp = vfirst;
	while(vtmp!=NULL){
		point start=vtmp->data.start;
		point end=vtmp->data.end;
		matrix[ordinal_Number(pfirst,end)-1][ordinal_Number(pfirst,start)-1]=vtmp->data.l;
		vtmp=vtmp->next;
	}	
	return matrix;
}

int **createMatrix(point_node *&pfirst,vector_node *&vfirst){
	int **matrix = new int*[countPoint(pfirst)];
	for(int i = 0; i<countPoint(pfirst); i++)
	   matrix[i] = new int[countPoint(pfirst)];
	 
	for(int i=0; i<countPoint(pfirst); i++){
		for(int j=0; j<countPoint(pfirst); j++){
			matrix[i][j]=0;
		}
	}
	  
	vector_node *vtmp = vfirst;
	while(vtmp!=NULL){
		point start=vtmp->data.start;
		point end=vtmp->data.end;
		matrix[ordinal_Number(pfirst,start)-1][ordinal_Number(pfirst,end)-1]=vtmp->data.l;
		vtmp=vtmp->next;
	}	
	return matrix;
}
