#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define MAXC 10000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000



int **createMatrixShortWay(point_node *&pfirst,vector_node *&vfirst){
	int **matrix = new int*[countPoint(pfirst)];
	for(int i = 0; i<countPoint(pfirst); i++)
	   matrix[i] = new int[countPoint(pfirst)];
	 
	for(int i=0; i<countPoint(pfirst); i++){
		for(int j=0; j<countPoint(pfirst); j++){
			if(i==j){
				matrix[i][j]=0;
			}
			else matrix[i][j]=MAXC;
		}
	}
	  
	vector_node *vtmp = vfirst;
	while(vtmp!=NULL){
		point start=vtmp->data.start;
		point end=vtmp->data.end;
		matrix[ordinal_Number(pfirst,start)-1][ordinal_Number(pfirst,end)-1]=vtmp->data.l;
		vtmp=vtmp->next;
	}	
	return matrix;
}

void shortestwayrun(point_node *&pfirst,vector_node *&vfirst,int pidstart,int pidend,bool VN){
	point pstart,pend;
	int n=countPoint(pfirst);
	int Trace[MAX];
	int **matrix=createMatrixShortWay(pfirst,vfirst);
	int start = ordinal_Number(pfirst,search_pid(pfirst,pidstart))-1;
	int end = ordinal_Number(pfirst,search_pid(pfirst,pidend))-1;
	int D[MAX];
	for(int i=0;i<n;i++){
		D[i]=matrix[start][i];
		Trace[i]=start;
	}
	D[start]=0;
	for(int k=0;k<=n-2;k++){
		for(int v=0;v<n;v++){
			for(int u=0;u<n;u++){
				if(D[v]>D[u]+matrix[u][v]){
					D[v]=D[u]+matrix[u][v];
					Trace[v]=u;
				}
			}
		}
	}
	if(D[end]==MAXC) {
//		cout<<"Khong co duong di";
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Khong co duong di");
		else 		outtextxy(305,775,"Don't have way");
	}
	else{
//		cout<<start<<"->"<<end<<":"<<D[end]<<endl;
		char charnum[50];
		convertToCharArray(charnum,D[end]);
		char tmp[STRMAX]={'\0'};
		strcat(tmp,findPointByOr(pfirst,start+1).name);
		strcat(tmp,"->");
		strcat(tmp,findPointByOr(pfirst,end+1).name);
		strcat(tmp,":");
		strcat(tmp,charnum);
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		outtextxy(305,775,tmp);
		strcpy(tmp,"");
		while(end!=start){
			pend=findPointByOr(pfirst,end+1);
			strcat(tmp,pend.name);
//			cout<<end<<"<--";
			strcat(tmp,"<-");
			end = Trace[end];
			if(end==start) strcat(tmp,findPointByOr(pfirst,end+1).name);
			pstart=findPointByOr(pfirst,end+1);
			drawLineWithValueRun(pstart.x,pstart.y,pend.x,pend.y,search_vectorst_SEtoValue(vfirst,pstart.id,pend.id));
		}
		cout<<tmp;
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		outWrapTextXY(305,795,90,20,tmp);
	}
}


