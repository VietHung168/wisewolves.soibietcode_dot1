	//vectors
	// NOTE: UNLESS CREATE THEN INSERT, id wont auto create
	#pragma once
	#include <iostream>
	#include "structure.h"
	#include "points.h"
	
	//count
		int id_vectors(vector_node *&first){
		vector_node *tmp=first;
		int s;
		if(first==NULL){
			s=2000;
			return s;
		}
		else {
		while(tmp->next!=NULL){
			tmp=tmp->next;
		}
		s = tmp->data.id;
		return s;
		}
	}
	
	//create:
	vector create_new_vector(vector_node *&first,point start,point end,int value){
		vector v;
//		std::cout<<"Start: ";
//		std::cin>>v.start;
//		std::cout<<"End: ";
//		std::cin>>v.end;
//		std::cout<<"Value: ";
//		std::cin>>v.l;
//		std::cout<<"ID: ";
		v.start=start;
		v.end=end;
		v.l=value;
		v.id=1+id_vectors(first);
		return v;
	}
	
	vector_node *create_new_vnode(vector v){
		vector_node *nodes = new vector_node;
		nodes->data=v;
		nodes->next=NULL;
		return nodes;
	}
	
	//insert:
	void insert_last_v(vector_node *&first,vector v){
		vector_node *tmp=create_new_vnode(v);
		if(first==NULL){
			first=tmp;
		}
		else{
			vector_node *run=first;
			while(1){
				if(run->next==NULL){
					run->next=tmp;
					break;
				}
				run=run->next;
			}
		}
	}
	
	//search
	bool search_vector_SE_BOOL(vector_node *first,int idstart,int idend){
		vector_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.start.id==idstart && tmp->data.end.id==idend){
//				std::cout<<tmp->data.start<<std::endl;
//				std::cout<<tmp->data.end<<std::endl;
//				std::cout<<tmp->data.l<<std::endl;
//				std::cout<<tmp->data.id<<std::endl;
				return true;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT point's ID"<<std::endl;
		return false;
	}
	
	int search_vectorst_SEtoID(vector_node *first,int idstart,int idend){
		vector_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.start.id==idstart && tmp->data.end.id==idend){
				return tmp->data.id;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT point's ID"<<std::endl;
	}
	
	int search_vectorst_SEtoValue(vector_node *first,int idstart,int idend){
		vector_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.start.id==idstart && tmp->data.end.id==idend){
				return tmp->data.l;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT point's ID"<<std::endl;
	}
	
	void edit_vid(vector_node *first,int vid,int value){
		vector_node *tmp = first;
		while(tmp!=NULL){
			if(tmp->data.id==vid){
//				std::cout<<tmp->data.start<<std::endl;
//				std::cout<<tmp->data.end<<std::endl;
//				std::cout<<tmp->data.l<<std::endl;
//				std::cout<<tmp->data.id<<std::endl;
				tmp->data.l=value;
				return;
			}
			tmp=tmp->next;
		}
//		std::cout<<"ERROR CAN'T FIND THAT vector's ID"<<std::endl;
	}
	
	//delete
	void delete_vectorID(vector_node *&first,int vid){
		vector_node *tmp = first;
		vector_node *node_del;
		if(tmp->data.id==vid) {
			node_del=tmp;
			first=tmp->next;
			delete node_del;
			return;
		}
		while(1){
			if(tmp->next->data.id==vid){
				node_del = tmp->next;
				tmp->next=node_del->next;
				delete node_del;
				return;
			}
			tmp=tmp->next;
			if(tmp->next==NULL) break;
		}
//		std::cout<<"ERROR CAN'T FIND VECTOR TO DELETE"<<std::endl;
	}
	
	void delete_vectorbyPoint(vector_node *&first,point p,bool &run){
		if(first==NULL) return;
		vector_node *tmp = first;
		vector_node *node_del;
		if(tmp->data.start.id==p.id||tmp->data.end.id==p.id) {
			node_del=tmp;
			first=tmp->next;
			delete node_del;
			return;
		}
		while(tmp->next!=NULL){
			if(tmp->next->data.start.id==p.id||tmp->next->data.end.id==p.id){
				node_del = tmp->next;
				tmp->next=node_del->next;
				delete node_del;
				return;
			}
			tmp=tmp->next;
			if(tmp->next==NULL) break;
		}
//		std::cout<<"ERROR CAN'T FIND VECTOR TO DELETE"<<std::endl;
		run=false;
	}
		
		
		
	
	
	
