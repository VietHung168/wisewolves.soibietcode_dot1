#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define MAXC 10000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000


int Kiemtra(int **matrix,int n){

	int s1=0, s2=0;

 	for(int i=0; i<n;i++){

		s1=0;
		s2=0;
		
//		std::cout<<"dinh "<<i<<std::endl;

		for(int j=0; j<n;j++){
			if (matrix[i][j] > 0) s1++;
			if (matrix[j][i] > 0) s2++;
		}
		
//		std::cout<<"s1"<<s1<<std::endl;
//		std::cout<<"s2"<<s2<<std::endl;
		
		if(s1!=s2) return(FALSE);
 	}
 	
// 	std::cout<<"true"<<std::endl;

 	return(TRUE);

}

void euler(point_node *&pfirst, vector_node *&vfirst,bool VN){
	int **matrix = createMatrix(pfirst,vfirst);
	
//	std::cout<<"matrix:"<<std::endl;
	
//	for(int i=0; i<3; i++){
//		for(int j=0; j<3; j++){
//			std::cout<<matrix[i][j]<<" ";
//		}
//		std::cout<<std::endl;
//	}
	
	int n=countPoint(pfirst);
//	std::cout<<"n: "<<n<<std::endl;
	if(Kiemtra(matrix,n)==TRUE){
//		std::cout<<"co chu trinh nha"<<std::endl;
		int u=0,v, x, top, dCE;
		int stack[MAX], CE[MAX];
		top=1;
		stack[top]=u;//th?m dinh u vao stack.
		dCE=0;
		do {
			v = stack[top];//lay dinh tren cung cua stack.
			x=0;
			while (x<n && matrix[v][x]==0) //tim trong danh sach nhung dinh ke voi dinh v.
				x++;
				
//			std::cout<<"x: "<<x<<std::endl;
			if (x>=n) { //l?y ra kh?i stack.
				dCE++;
		    	CE[dCE]=v;//luu d?nh v v?o m?ng k?t qu? duy?t CE.
//		    	std::cout<<"CE["<<dCE<<"]: "<<CE[dCE]<<std::endl;
		    	top--;
		  	}
		  	else { //d?nh x l? d?nh k? v?i d?nh v.
			   	top++;
			   	stack[top]=x;
			   	matrix[v][x]=0;
//			   	matrix[x][v]=0;
		  	}
	 	} while(top!=0);
//	 	cout<<"\nCo chu trinh Euler:\n";
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Co chu trinh Euler:");
		else 		outtextxy(305,775,"Have Euler cycle:");
		point p;
		char tmp[STRMAX]={'\0'};
	 	for(int x=dCE; x>=1; x--) {
//	 		cout<<CE[x]<<"-"; //in ra k?t qu? du?i d?ng char.
			p=findPointByOr(pfirst,CE[x]+1);
			if(x!=1) {
				strcat(tmp,p.name);
				strcat(tmp,"->");
			}
			else strcat(tmp,p.name);
		}
		outWrapTextXY(305,795,90,20,tmp);
	  	for(x=dCE; x>1; x--){
		 	point pstart,pend;
//		 	std::cout<<"CE["<<x<<"]: "<<CE[x]<<std::endl;
//		 	std::cout<<"CE["<<x-1<<"]: "<<CE[x-1]<<std::endl;
		 	pstart=findPointByOr(pfirst,CE[x]+1);
		 	pend=findPointByOr(pfirst,CE[x-1]+1);
//		 	std::cout<<"draw line"<<CE[x];
//		 	std::cout<<" - "<<CE[x-1]<<std::endl;
		 	drawLineRun(pstart.x,pstart.y,pend.x,pend.y);
			delay(300);
		}
	}
 	
	else{
//		cout<<"\nKhong co chu trinh Euler";
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Khong co chu trinh Euler");
		else 		outtextxy(305,775,"Don't have Euler cycle");
	}
		
}
