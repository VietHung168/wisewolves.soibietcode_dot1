#pragma once
#include "graphic.h"
#include "points.h"
#include <iostream>
#include <string.h>
#include "file.h"
#include "dfs-bfs.h"
#include "shortestway.h"
#include "euler.h"
#include "hamilton.h"
#include "bridge.h"
#include "mid_vertex.h"
#include "cut_vertex.h"
#include "connected_component.h"
#include "topo.h"
#include <stdlib.h>


//input and out on screen

void inputname(int x, int y, char s[]){
	
	settextjustify(0,0);
	settextstyle(0,0,2);
	
	setbkcolor(15);
	setcolor(0);
	
	settextstyle(0, 0, 2);	
	
	int l=strlen(s);
	
	s[l+1]='\0';
    s[l]='|';
    
	 
    while(true){
     	
		outtextxy(x,y,s);
		
     	if(kbhit()){
     		char c= getch();
	     	if(l<=9 && ('a'<=c&&c<='z'||'A'<=c&&c<='Z'||'0'<=c&&c<='9'||c==' '))
	     	{
	     		s[l]=c;
			 	l++;
			 	s[l+1]='\0';
			 	outtextxy(x,y,s);
			}
			else if(l!=0 && c==8){
				s[l-1]='|';
				s[l]=' ';
				outtextxy(x,y,s);
				l--;
			} 
			else if(c==13){
				s[l]='\0';
				break;
			}
		 	
		}
		else{
		
			s[l]='|';
			delay(100);
			outtextxy(x,y,s);
			s[l]=' ';
			delay(100);
			outtextxy(x,y,s);
		 
		}
	}
	
}

void input(int x, int y, char s[]){
	
	settextjustify(0,0);
	settextstyle(0,0,2);
	
	setbkcolor(15);
	setcolor(0);
	
	settextstyle(0, 0, 2);	
	
	int l=strlen(s);
	
	s[l+1]='\0';
    s[l]='|';
    
	 
    while(true){
     	
		outtextxy(x,y,s);
		
     	if(kbhit()){
     		char c= getch();
	     	if('a'<=c&&c<='z'||'A'<=c&&c<='Z'||'0'<=c&&c<='9'||c==' ')
	     	{
	     		s[l]=c;
			 	l++;
			 	s[l+1]='\0';
			 	outtextxy(x,y,s);
			}
			else if(l!=0 && c==8){
				s[l-1]='|';
				s[l]=' ';
				outtextxy(x,y,s);
				l--;
			} 
			else if(c==13){
				s[l]='\0';
				break;
			}
		 	
		}
		else{
		
			s[l]='|';
			delay(100);
			outtextxy(x,y,s);
			s[l]=' ';
			delay(100);
			outtextxy(x,y,s);
		 
		}
	}
	
}

void inputNum(int x, int y, char s[]){
	
	settextjustify(0,0);
	settextstyle(0,0,2);
	
	setbkcolor(15);
	setcolor(0);
	
	settextstyle(0, 0, 2);	
	
	int l=strlen(s);
	
	s[l+1]='\0';
    s[l]='|';
    
	 
    while(true){
     	
		outtextxy(x,y,s);
		
     	if(kbhit()){
     		char c= getch();
	     	if('0'<=c&&c<='9')
	     	{
	     		s[l]=c;
			 	l++;
			 	s[l+1]='\0';
			 	outtextxy(x,y,s);
			}
			else if(c==8){
				s[l-1]='|';
				s[l]=' ';
				outtextxy(x,y,s);
				l--;
			} 
			else if(c==13){
				s[l]='\0';
				break;
			}
		 	
		}
		else{
		
			s[l]='|';
			delay(100);
			outtextxy(x,y,s);
			s[l]=' ';
			delay(100);
			outtextxy(x,y,s);
		 
		}
	}
	
}

void reset_draw_area(){
	setfillstyle(1,11);
	bar(300,0,1600,750);	
}

void reset_btnsub_area(){
	setbkcolor(15);
	setcolor(0);
	setfillstyle(1,15);
	bar(150,0,300,600);
	rectangle(150,0,300,600);
}

// BOX INPUT,WARNING..v.v..
//x<300 || x>1600 || y<0 || y>750
//x+950
//y+375

void draw_inputPointBox(int **map_id,bool VN){
	setbkcolor(7);
	setfillstyle(1,7);
	setcolor(10);
	bar(550,225,1350,525);
	rectangle(550,225,1350,525);
	settextstyle(0,0,3);
	settextjustify(1,1);
	setfillstyle(1,15);
	setcolor(0);
	if(VN) 	outtextxy(950,300,"HAY NHAP TEN DINH:");
	else 	outtextxy(950,300,"PLEASE INPUT VERTEX'S NAME:");
	setbkcolor(15);
	setfillstyle(1,15);
	bar(650,325,1250,375);
	set_id(map_id,650,325,1250,375,999900);
	rectangle(650,325,1250,375);
	settextstyle(0,0,2);
//	setfillstyle(1,7);
//	setbkcolor(7);
	bar(650,425,850,500);
	rectangle(650,425,850,500);
	if(VN) 	outtextxy(750,463,"TAO");
	else	outtextxy(750,463,"CREATE");
	set_id(map_id,650,425,850,500,999901);
	bar(1050,425,1250,500);
	rectangle(1050,425,1250,500);
	if(VN) 	outtextxy(1150,463,"HUY");
	else	outtextxy(1150,463,"CANCEL");
	set_id(map_id,1050,425,1250,500,999902);
}

void draw_inputVectorBox(int **map_id,bool VN){
	setbkcolor(7);
	setfillstyle(1,7);
	setcolor(10);
	bar(550,225,1350,525);
	rectangle(550,225,1350,525);
	settextstyle(0,0,3);
	settextjustify(1,1);
	setfillstyle(1,15);
	setcolor(0);
	if(VN) 	outtextxy(950,300,"HAY NHAP GIA TRI CANH :");
	else 	outtextxy(950,300,"PLEASE INPUT EDGE'S VALUE :");
	setbkcolor(15);
	setfillstyle(1,15);
	bar(650,325,1250,375);
	set_id(map_id,650,325,1250,375,999910);
	rectangle(650,325,1250,375);
	settextstyle(0,0,2);
//	setfillstyle(1,7);
//	setbkcolor(7);
	bar(650,425,850,500);
	rectangle(650,425,850,500);
	if(VN) 	outtextxy(750,463,"TAO");
	else 	outtextxy(750,463,"CREATE");
	set_id(map_id,650,425,850,500,999911);
	bar(1050,425,1250,500);
	rectangle(1050,425,1250,500);
	if(VN) 	outtextxy(1150,463,"HUY");
	else 	outtextxy(1150,463,"CANCEL");
	set_id(map_id,1050,425,1250,500,999902);
}

void draw_saveBox(int **map_id,bool VN){
	setbkcolor(7);
	setfillstyle(1,7);
	setcolor(10);
	bar(550,225,1350,525);
	rectangle(550,225,1350,525);
	settextstyle(0,0,3);
	settextjustify(1,1);
	setfillstyle(1,15);
	setcolor(0);
	if(VN) 	outtextxy(950,300,"HAY NHAP TEN TEP TIN :");
	else 	outtextxy(950,300,"PLEASE INPUT FILE'S NAME :");
	setbkcolor(15);
	setfillstyle(1,15);
	bar(650,325,1250,375);
	set_id(map_id,650,325,1250,375,999920);
	rectangle(650,325,1250,375);
	settextstyle(0,0,2);
//	setfillstyle(1,7);
//	setbkcolor(7);
	bar(650,425,850,500);
	rectangle(650,425,850,500);
	if(VN) 	outtextxy(750,463,"LUU");
	else 	outtextxy(750,463,"SAVE");
	set_id(map_id,650,425,850,500,999921);
	bar(1050,425,1250,500);
	rectangle(1050,425,1250,500);
	if(VN) 	outtextxy(1150,463,"HUY");
	else 	outtextxy(1150,463,"CANCEL");
	set_id(map_id,1050,425,1250,500,999902);
}

void draw_openBox(int **map_id,bool VN){
	setbkcolor(7);
	setfillstyle(1,7);
	setcolor(10);
	bar(550,225,1350,525);
	rectangle(550,225,1350,525);
	settextstyle(0,0,3);
	settextjustify(1,1);
	setfillstyle(1,15);
	setcolor(0);
	if (VN) 	outtextxy(950,300,"HAY NHAP TEN TEP TIN :");
	else 	outtextxy(950,300,"PLEASE INPUT FILE'S NAME :");
	setbkcolor(15);
	setfillstyle(1,15);
	bar(650,325,1250,375);
	set_id(map_id,650,325,1250,375,999920);
	rectangle(650,325,1250,375);
	settextstyle(0,0,2);
//	setfillstyle(1,7);
//	setbkcolor(7);
	bar(650,425,850,500);
	rectangle(650,425,850,500);
	outtextxy(750,463,"OPEN");
	set_id(map_id,650,425,850,500,999931);
	bar(1050,425,1250,500);
	rectangle(1050,425,1250,500);
	outtextxy(1150,463,"CANCEL");
	set_id(map_id,1050,425,1250,500,999902);
}

void draw_askSaveBox(int **map_id, bool VN){
	setbkcolor(7);
	setfillstyle(1,7);
	setcolor(10);
	bar(550,225,1350,525);
	rectangle(550,225,1350,525);
	settextstyle(0,0,3);
	settextjustify(1,1);
	setfillstyle(1,15);
	setcolor(0);
	if(VN) 	outtextxy(950,300,"BAN CO MUON LUU LAI KHONG?");
	else 	outtextxy(950,300,"DO YOU WANT TO SAVE?");
	setbkcolor(15);
	setfillstyle(1,15);
//	bar(650,325,1250,375);
//	set_id(map_id,650,325,1250,375,999920);
//	rectangle(650,325,1250,375);
	settextstyle(0,0,2);
//	setfillstyle(1,7);
//	setbkcolor(7);
	bar(650,425,850,500);
	rectangle(650,425,850,500);
	if(VN) 	outtextxy(750,463,"CO");
	else 	outtextxy(750,463,"YES");
	set_id(map_id,650,425,850,500,999941);
	bar(1050,425,1250,500);
	rectangle(1050,425,1250,500);
	if(VN) 	outtextxy(1150,463,"KHONG");
	else 	outtextxy(1150,463,"NO");
	set_id(map_id,1050,425,1250,500,999942);
}

//ENGLISH

//MENU BUTTON
void btn_file(int **map_id,bool VN){
	if(VN) 	create_btn(map_id,0,0,150,200,0,"TEP TIN");
	else 	create_btn(map_id,0,0,150,200,0,"FILE");
}

void btn_edit(int **map_id,bool VN){
	if(VN) 	create_btn(map_id,0,200,150,400,10,"CHINH SUA");
	else create_btn(map_id,0,200,150,400,10,"EDIT");
}

void btn_action(int **map_id,bool VN){
	if(VN) 	create_btn(map_id,0,400,150,600,20,"TAC VU");
	else 	create_btn(map_id,0,400,150,600,20,"ACTION");
}
//MENU BUTTON FOCUS
void btn_file_focus(int **map_id,bool VN){
	if(VN) 	create_btn_focus(map_id,0,0,150,200,0,"TEP TIN");
	else 	create_btn_focus(map_id,0,0,150,200,0,"FILE");
}

void btn_edit_focus(int **map_id,bool VN){
	if(VN) 	create_btn_focus(map_id,0,200,150,400,10,"CHINH SUA");
	else create_btn_focus(map_id,0,200,150,400,10,"EDIT");
}

void btn_action_focus(int **map_id,bool VN){
	if(VN) 	create_btn_focus(map_id,0,400,150,600,20,"TAC VU");
	else 	create_btn_focus(map_id,0,400,150,600,20,"ACTION");
}

// SUB-BTN OF FILE
void btn_new_grap(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,0,300,50,1,"TAO MOI");
	else	create_subbtn(map_id,150,0,300,50,1,"NEW");
}

void btn_open_grap(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,50,300,100,2,"MO TEP");
	else	create_subbtn(map_id,150,50,300,100,2,"OPEN");
}

void btn_save(int **map_id, bool VN){
	if(VN) 	create_subbtn(map_id,150,100,300,150,3,"LUU TEP");
	else	create_subbtn(map_id,150,100,300,150,3,"SAVE");
}

//void btn_eng(int **map_id){
//	create_subbtn(map_id,150,150,300,200,4,"ENGLISH");
//}

void btn_vn(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,150,300,200,4,"ENGLISH");
	else 	create_subbtn(map_id,150,150,300,200,4,"VIETNAM");
}

void btn_exit(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,200,300,250,5,"THOAT");
	else 	create_subbtn(map_id,150,200,300,250,5,"EXIT");
}

//SUB-BTN FILE FOCUS
void btn_new_grap_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,0,300,50,1,"TAO MOI");
	else	create_subbtn_focus(map_id,150,0,300,50,1,"NEW");
}

void btn_open_grap_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,50,300,100,2,"MO TEP");
	else	create_subbtn_focus(map_id,150,50,300,100,2,"OPEN");
}

void btn_save_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,100,300,150,3,"LUU TEP");
	else 	create_subbtn_focus(map_id,150,100,300,150,3,"SAVE");
}
//
//void btn_eng_focus(int **map_id){
//	create_subbtn_focus(map_id,150,150,300,200,4,"ENGLISH");
//}

void btn_vn_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,150,300,200,4,"ENGLISH");
	else	create_subbtn_focus(map_id,150,150,300,200,4,"VIETNAM");
}

void btn_exit_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,200,300,250,5,"THOAT");
	else 	create_subbtn_focus(map_id,150,200,300,250,5,"EXIT");
}

//SUB-BTN EDIT
void btn_add_vertex(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,0,300,50,13,"THEM DINH");
else 	create_subbtn(map_id,150,0,300,50,13,"ADD VERTEX");
}

void btn_add_edge(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,50,300,100,14,"THEM CANH");
	else 	create_subbtn(map_id,150,50,300,100,14,"ADD EDGE");
}

void btn_edit_vertex(int **map_id,bool VN){
	if(VN) 	create_subbtn_db(map_id,150,100,300,150,15,"CHINH SUA","DINH");
	else 	create_subbtn(map_id,150,100,300,150,15,"EDIT VERTEX");
}

void btn_edit_edge(int **map_id,bool VN){
	if(VN) 	create_subbtn_db(map_id,150,150,300,200,16,"CHINH SUA","CANH");
	else	create_subbtn(map_id,150,150,300,200,16,"EDIT EDGE");
}

void btn_del_vertex(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,200,300,250,17,"XOA DINH");
	else 	create_subbtn(map_id,150,200,300,250,17,"DELETE VERTEX");
}

void btn_del_edge(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,250,300,300,18,"XOA CANH");
	else	create_subbtn(map_id,150,250,300,300,18,"DELETE EDGE");
}
//
//void btn_del_vertex(int **map_id){
//	create_subbtn(map_id,150,300,300,350,17,"DELETE VERTEX");
//}
//
//void btn_del_edge(int **map_id){
//	create_subbtn(map_id,150,350,300,400,18,"DELETE EDGE");
//}

//SUB-BTN EDIT FOCUS
void btn_add_vertex_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,0,300,50,13,"THEM DINH");
else 	create_subbtn_focus(map_id,150,0,300,50,13,"ADD VERTEX");
}

void btn_add_edge_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,50,300,100,14,"THEM CANH");
	else 	create_subbtn_focus(map_id,150,50,300,100,14,"ADD EDGE");
}

void btn_edit_vertex_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_db_focus(map_id,150,100,300,150,15,"CHINH SUA","DINH");
	else 	create_subbtn_focus(map_id,150,100,300,150,15,"EDIT VERTEX");
}

void btn_edit_edge_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_db_focus(map_id,150,150,300,200,16,"CHINH SUA","CANH");
	else	create_subbtn_focus(map_id,150,150,300,200,16,"EDIT EDGE");
}

void btn_del_vertex_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,200,300,250,17,"XOA DINH");
	else 	create_subbtn_focus(map_id,150,200,300,250,17,"DELETE VERTEX");
}

void btn_del_edge_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,250,300,300,18,"XOA CANH");
	else	create_subbtn_focus(map_id,150,250,300,300,18,"DELETE EDGE");
}

//void btn_del_vertex_focus(int **map_id){
//	create_subbtn_focus(map_id,150,300,300,350,17,"DELETE VERTEX");
//}
//
//void btn_del_edge_focus(int **map_id){
//	create_subbtn_focus(map_id,150,350,300,400,18,"DELETE EDGE");
//}

//SUB-BTN ACTION
void btn_dfs(int **map_id){
	create_subbtn(map_id,150,0,300,50,21,"DFS");
}

void btn_bfs(int **map_id){
	create_subbtn(map_id,150,50,300,100,22,"BFS");
}

void btn_connected_component(int **map_id,bool VN){
	if(VN) 	create_subbtn_db(map_id,150,100,300,150,23,"THANH PHAN","LIEN THONG");
	else 	create_subbtn_db(map_id,150,100,300,150,23,"CONNECTED","COMPONENT");
}

void btn_shortest_path(int **map_id,bool VN){
	if(VN) create_subbtn_db(map_id,150,150,300,200,24,"DUONG DI","NGAN NHAT");
	else create_subbtn(map_id,150,150,300,200,24,"SHORTEST PATH");
}

void btn_cut_vertex(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,200,300,250,25,"DINH TRU");
	else 	create_subbtn(map_id,150,200,300,250,25,"CUT VERTEXT");
}

void btn_mid_vertex(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,250,300,300,26,"DINH THAT");
	else 	create_subbtn(map_id,150,250,300,300,26,"MID VERTEXT");
}

void btn_bridge(int **map_id,bool VN){
	if(VN) 	create_subbtn(map_id,150,300,300,350,27,"CANH CAU");
	else 	create_subbtn(map_id,150,300,300,350,27,"BRIDGE");
}

void btn_hamilton(int **map_id){
	create_subbtn(map_id,150,350,300,400,28,"HAMILTON");
}

void btn_euler(int **map_id){
	create_subbtn(map_id,150,400,300,450,29,"EULER");
}

void btn_topo_sort(int **map_id,bool VN){
	if(VN) 	create_subbtn_db(map_id,150,450,300,500,30,"SAP XEP","TOPO");
	create_subbtn(map_id,150,450,300,500,30,"TOPO SORT");
}

//SUB-BTN ACTION FOCUS
void btn_dfs_focus(int **map_id){
	create_subbtn_focus(map_id,150,0,300,50,21,"DFS");
}

void btn_bfs_focus(int **map_id){
	create_subbtn_focus(map_id,150,50,300,100,22,"BFS");
}

void btn_connected_component_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_db_focus(map_id,150,100,300,150,23,"THANH PHAN","LIEN THONG");
	else 	create_subbtn_db_focus(map_id,150,100,300,150,23,"CONNECTED","COMPONENT");
}

void btn_shortest_path_focus(int **map_id,bool VN){
	if(VN) create_subbtn_db_focus(map_id,150,150,300,200,24,"DUONG DI","NGAN NHAT");
	else create_subbtn_focus(map_id,150,150,300,200,24,"SHORTEST PATH");
}

void btn_cut_vertex_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,200,300,250,25,"DINH TRU");
	else 	create_subbtn_focus(map_id,150,200,300,250,25,"CUT VERTEXT");
}

void btn_mid_vertex_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,250,300,300,26,"DINH THAT");
	else 	create_subbtn_focus(map_id,150,250,300,300,26,"MID VERTEXT");
}

void btn_bridge_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_focus(map_id,150,300,300,350,27,"CANH CAU");
	else 	create_subbtn_focus(map_id,150,300,300,350,27,"BRIDGE");
}

void btn_hamilton_focus(int **map_id){
	create_subbtn_focus(map_id,150,350,300,400,28,"HAMILTON");
}

void btn_euler_focus(int **map_id){
	create_subbtn_focus(map_id,150,400,300,450,29,"EULER");
}

void btn_topo_sort_focus(int **map_id,bool VN){
	if(VN) 	create_subbtn_db_focus(map_id,150,450,300,500,30,"SAP XEP","TOPO");
	create_subbtn_focus(map_id,150,450,300,500,30,"TOPO SORT");
}

//DRAW SUB-BTN WHEN FOCUS BTN MENU
void btn_subFile(int **map_id,bool VN){
	btn_new_grap(map_id,VN);
	btn_open_grap(map_id,VN);
	btn_save(map_id,VN);
	btn_vn(map_id,VN);
	btn_exit(map_id,VN);
}

void btn_subEdit(int **map_id,bool VN){
	btn_add_vertex(map_id,VN);
	btn_add_edge(map_id,VN);
	btn_edit_vertex(map_id,VN);
	btn_edit_edge(map_id,VN);
	btn_del_vertex(map_id,VN);
	btn_del_edge(map_id,VN);
}

void btn_subAction(int **map_id,bool VN){
	btn_dfs(map_id);
	btn_bfs(map_id);
	btn_connected_component(map_id,VN);
	btn_shortest_path(map_id,VN);
	btn_cut_vertex(map_id,VN);
	btn_mid_vertex(map_id,VN);
	btn_bridge(map_id,VN);
	btn_hamilton(map_id);
	btn_euler(map_id);
	btn_topo_sort(map_id,VN);
}

//DRAW MATRIX
void drawMatrix(point_node *&pfirst, vector_node *&vfirst,bool VN){
	drawView(0,600,300,900,15,0,0);
	settextstyle(0,0,2);
	settextjustify(1,2);
	setcolor(4);
	if(VN) 	outtextxy(150,610,"MA TRAN");
	else 	outtextxy(150,610,"MATRIX");
	drawTable(countPoint(pfirst)+1,countPoint(pfirst)+1, 10, 635,290, 880, pfirst, vfirst);
}

//DRAW MENU WHEN PROGRAM START
void draw_menu_start(int **map_id,bool VN){
	create_menu_bar(map_id,VN);
	btn_file(map_id,VN);
	btn_edit(map_id,VN);
	btn_action(map_id,VN);
}

void draw_menu(int **map_id,point_node *&pfirst, vector_node *&vfirst,bool VN){
	create_menu_bar(map_id,VN);
	btn_file(map_id,VN);
	btn_edit(map_id,VN);
	btn_action(map_id,VN);
	drawMatrix(pfirst,vfirst,VN);
}

void reset_btnMenu(int **map_id,bool VN){
	btn_file(map_id,VN);
	btn_edit(map_id,VN);
	btn_action(map_id,VN);
}

//REDRAW POINT + VECTOR

void reDraw(point_node *&pfirst, vector_node *&vfirst){
	point_node *ptmp=pfirst;
	vector_node *vtmp=vfirst;
	int x1,x2,y1,y2,value;
	while(vtmp!=NULL){
		x1=vtmp->data.start.x;
		y1=vtmp->data.start.y;
		x2=vtmp->data.end.x;
		y2=vtmp->data.end.y;
		value=vtmp->data.l;
		drawLineWithValue(x1,y1,x2,y2,value);
		vtmp=vtmp->next;
	}
	while(ptmp!=NULL){
		draw_point(ptmp->data);
		ptmp=ptmp->next;					
	}
}

void reDrawWithVID(int **map_id,point_node *&pfirst, vector_node *&vfirst){
	point_node *ptmp=pfirst;
	vector_node *vtmp=vfirst;
	int x1,x2,y1,y2,value,id;
	while(vtmp!=NULL){
		x1=vtmp->data.start.x;
		y1=vtmp->data.start.y;
		x2=vtmp->data.end.x;
		y2=vtmp->data.end.y;
		value=vtmp->data.l;
		id=vtmp->data.id;
		drawLineWithValue(x1,y1,x2,y2,value);
		setLineID(map_id,x1,y1,x2,y2,id);
		vtmp=vtmp->next;
	}
	while(ptmp!=NULL){
		draw_point(ptmp->data);
		ptmp=ptmp->next;					
	}
}

void reDrawWithPID(int **map_id,point_node *&pfirst, vector_node *&vfirst){
	point_node *ptmp=pfirst;
	vector_node *vtmp=vfirst;
	int x1,x2,y1,y2,value;
	while(vtmp!=NULL){
		x1=vtmp->data.start.x;
		y1=vtmp->data.start.y;
		x2=vtmp->data.end.x;
		y2=vtmp->data.end.y;
		value=vtmp->data.l;
		drawLineWithValue(x1,y1,x2,y2,value);
		vtmp=vtmp->next;
	}
	while(ptmp!=NULL){
		create_point(map_id,ptmp->data);
		ptmp=ptmp->next;					
	}
}

//RUN
void run_project(int **map_id){
	point_node *pfirst= NULL;
	vector_node *vfirst= NULL;
	int a,b,value,findid;
	point pstart,pend;
	int editAction =0;
	char name[10]="";
	char filename[]="";
	char charvalue[]="";
	bool VN=false;
	while(1){
		if(kbhit()) char tmpC=getch();
		if(ismouseclick(WM_LBUTTONDOWN)){
			int x,y,id;
			getmouseclick(WM_LBUTTONDOWN,x,y);
			id=map_id[x][y];
//			std::cout<<"ID: "<<id<<endl;
//			std::cout<<"x: "<<x<<",y: "<<y<<endl;
			switch(id){
				case 0:{ //FILE
					reset_btnMenu(map_id,VN);
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_file_focus(map_id,VN);
					btn_subFile(map_id,VN);
					reset_draw_area_id(map_id);
					editAction=0;
					break;
				}
				
				case 1:{ //new
					if(pfirst==NULL){
						clearData(pfirst,vfirst);
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu_start(map_id,VN);
					}
					else {
						btn_new_grap_focus(map_id,VN);
						reset_map_id(map_id);
						draw_askSaveBox(map_id,VN);
						editAction=4;
					}
					break;
				}
				
				
				case 2:{ //open
					if(pfirst==NULL){
						btn_open_grap_focus(map_id,VN);
						reset_map_id(map_id);
						draw_openBox(map_id,VN);
					}
					else {
						btn_open_grap_focus(map_id,VN);
						reset_map_id(map_id);
						draw_askSaveBox(map_id,VN);
						editAction=8;
					}
					
					break;
				}
				
				case 3:{ //save
					if(pfirst!=NULL){
						btn_save_focus(map_id,VN);
						reset_map_id(map_id);
						draw_saveBox(map_id,VN);
					}
					break;
				}
				
				case 4:{ //Langue
					if(VN==false) VN=true;
					else VN=false;
					draw_menu(map_id,pfirst,vfirst,VN);
					reset_btnMenu(map_id,VN);
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_file_focus(map_id,VN);
					btn_subFile(map_id,VN);
					reset_draw_area_id(map_id);				
					break;
				}
				
				case 5:{ //exit
					if(pfirst==NULL){
						exit(0);
					}
					else{
						btn_exit_focus(map_id,VN);
						reset_map_id(map_id);
						draw_askSaveBox(map_id,VN);
						editAction=9;
					}
					break;
				}
				
				case 10:{ //EDIT
					reset_btnMenu(map_id,VN);
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					reset_draw_area_id(map_id);
					editAction=0;
					break;
				}

// editAction 1 = draw edge, 2 = delete vertex , 3 = edit vertex, 4 = save before new + file sub-btn, 5 run dfs, 6 run bfs
// editAction 7 = shortest path , 8 = save before open , 9 = save before exit

				case 13:{ //add vertex
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_add_vertex_focus(map_id,VN);
					set_draw_area_id(map_id);
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=0;
					break;
				}
				
				case 14:{ //add edge
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_add_edge_focus(map_id,VN);
					reset_draw_area_id(map_id);
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=1;
					break;
				}
				
				case 15:{ //edit vertex
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_edit_vertex_focus(map_id,VN);
					reset_draw_area_id(map_id);
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=3;
					break;
				}
				
				case 16:{ //edit edge
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_edit_edge_focus(map_id,VN);
					reset_draw_area_id(map_id);
					reDrawWithVID(map_id,pfirst,vfirst);
					editAction=3;
					break;
				}
				
				case 17:{ //delete vertex
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_del_vertex_focus(map_id,VN);
					reset_draw_area_id(map_id);
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=2;
					break;
				}
				
				case 18:{ //edit edge
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_edit_focus(map_id,VN);
					btn_subEdit(map_id,VN);
					btn_del_edge_focus(map_id,VN);
					reset_draw_area_id(map_id);
					reDrawWithVID(map_id,pfirst,vfirst);
					editAction=2;
					break;
				}
				
				case 20:{ //ACTION
					reset_btnMenu(map_id,VN);
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					reset_draw_area_id(map_id);
					editAction=0;
					break;
				}
				
				case 21:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_dfs_focus(map_id);
					reset_draw_area_id(map_id);
					reset_Result_area();
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=5;
					break;
				}
				
				case 22:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_bfs_focus(map_id);
					reset_draw_area_id(map_id);
					reset_Result_area();
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=6;
					break;
				}
				
				case 23:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_connected_component_focus(map_id,VN);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					scc(pfirst,vfirst,VN);
					break;
				}
				
				case 24:{ //choose 2 point to find shortest way editAction=7
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_shortest_path_focus(map_id,VN);
					reset_Result_area();
					reDrawWithPID(map_id,pfirst,vfirst);
					editAction=7;
					break;
				}
				
				case 25:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_cut_vertex_focus(map_id,VN);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					cut_vertex(pfirst,vfirst,VN);//dinh tru
					break;
				}
				
				case 26:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_mid_vertex_focus(map_id,VN);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					mid_vertex(pfirst,vfirst,VN);//dinh that
					break;
				}
				
				case 27:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_bridge_focus(map_id,VN);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					bridge(pfirst,vfirst,VN);
					break;
				}
				
				case 28:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_hamilton_focus(map_id);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					Hamilton(pfirst,vfirst,VN);
					break;
				}
				
				case 29:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_euler_focus(map_id);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					euler(pfirst,vfirst,VN);
					break;
				}

				case 30:{
					reset_draw_area();
					reset_btnsub_id(map_id);
					reset_btnsub_area();
					btn_action_focus(map_id,VN);
					btn_subAction(map_id,VN);
					btn_topo_sort_focus(map_id,VN);
					reset_Result_area();
					reDraw(pfirst,vfirst);
					topo(pfirst,vfirst,VN);
					break;
				}
				
				case 9999:{ //DRAW POINT
					if(x<300+10 || x>1600-10 || y<0+10 || y>750-10) break;
					else{
						a=x;
						b=y;
						reset_map_id(map_id);
						draw_inputPointBox(map_id,VN);						
					break;
					}
				}
			
			
			
				case 999900:{//add point NAME BOX INPUT
					inputname(660,360,name);
					break;
				}
				
				case 999901:{//add point BTN CREATE
					if(editAction!=3){
						if(strlen(StripSpaces(name))!=0){
							point p=create_new_point(a, b,name,pfirst);
							insert_last_p(pfirst,p);
						}
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu(map_id,pfirst,vfirst,VN);
						reDraw(pfirst,vfirst);
						strcpy(name,"");
					}
					else{
						if(StripSpaces(name)!=""){
							edit_pid(pfirst,findid,name);
						}
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu(map_id,pfirst,vfirst,VN);
						reDraw(pfirst,vfirst);
						strcpy(name,"");
						editAction=0;
					}	
					break;
				}
				
				case 999902:{//add point BTN CANCEL
					if(editAction!=4){
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu(map_id,pfirst,vfirst,VN);
						reDraw(pfirst,vfirst);
						strcpy(name,"");
						strcpy(filename,"");
						editAction=0;
					}
					else{// when ask for save cancel edit action ==4
						editAction=0;
						clearData(pfirst,vfirst);
						reset_map_id(map_id);
						draw_menu_start(map_id,VN);
					}
					break;
				}
				
				case 999910:{// add vector INPUT
					inputNum(660,360,charvalue);
					value=convertToInt(charvalue);
					strcpy(charvalue,"");
					break;
				}
				
				case 999911:{// add vector CREATE
					if(editAction!=3){
						if(value>0){
							vector v=create_new_vector(vfirst,pstart,pend,value);
							insert_last_v(vfirst,v);
						}
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu(map_id,pfirst,vfirst,VN);
						reDraw(pfirst,vfirst);
					}
					else{
						if(value>0){
							edit_vid(vfirst,findid,value);
						}
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu(map_id,pfirst,vfirst,VN);
						reDraw(pfirst,vfirst);
						editAction=0;
					}
					break;
				}
				
//				case 999912:{// add vector CANCEL
//					reset_map_id(map_id);
//					reset_draw_area();
//					draw_menu(map_id,pfirst,vfirst);
//					reDraw(pfirst,vfirst);
//					editAction=0;
//					break;
//				}
				
				case 999920:{//SAVE FILE INPUT NAME BOX
					input(660,360,filename);
					break;
				}
				
				case 999921:{
					if(editAction==4){ //before new
						editAction=0;
						int **matrix=createMatrix(pfirst,vfirst);
						saveGraph(matrix,pfirst,vfirst,filename);
						clearData(pfirst,vfirst);
						reset_map_id(map_id);
						draw_menu_start(map_id,VN);
					}
					else if(editAction==8){ //before open
							editAction=0;
							reset_map_id(map_id);
							draw_openBox(map_id,VN);
						}
						else if(editAction==9){ //before exit
							editAction=0;
							reset_map_id(map_id);
							exit(0);

						}
						else {// save savebox
							int **matrix=createMatrix(pfirst,vfirst);
							saveGraph(matrix,pfirst,vfirst,filename);
							reset_map_id(map_id);
							reset_draw_area();
							draw_menu(map_id,pfirst,vfirst,VN);
							reDraw(pfirst,vfirst);
							strcpy(name,"");
						}
					
					break;
					
				}
				
				case 999931:{ //open btn
					openGraph(pfirst,vfirst,filename);
					reset_map_id(map_id);
					reset_draw_area();
					draw_menu(map_id,pfirst,vfirst,VN);
					reDraw(pfirst,vfirst);
					strcpy(name,"");
					break;
				}
				
				case 999941:{// btn yes box ask
					btn_new_grap_focus(map_id,VN);
					reset_draw_area();
					reset_map_id(map_id);
					draw_saveBox(map_id,VN);
					break;
				}
				
				case 999942:{ //btn no box ask
					if(editAction==4){ //before new
						editAction=0;
						clearData(pfirst,vfirst);
						reset_map_id(map_id);
						reset_draw_area();
						draw_menu_start(map_id,VN);
					}
					else if(editAction==8){ //before open
							editAction=0;
							int **matrix=createMatrix(pfirst,vfirst);
							saveGraph(matrix,pfirst,vfirst,filename);
							reset_map_id(map_id);
							draw_openBox(map_id,VN);
						}
						else if(editAction==9){ //before exit
							editAction=0;
							int **matrix=createMatrix(pfirst,vfirst);
							saveGraph(matrix,pfirst,vfirst,filename);
							reset_map_id(map_id);
							exit(0);
						}					
					break;
				}
				
				default:{
				 	//neu trong khoang id diem thi
				 	if(id<=2000 && id>1000){ 
						if(editAction==1){ //veduong
							pstart=search_pid(pfirst,id);
							a = pstart.x, b = pstart.y; //voi a,b lan luoc la x,y cua dinh bat dau
							int endX = a, endY = b;
							while(true){
								if(ismouseclick(WM_MOUSEMOVE)){
									clearLine(a,b,endX,endY);
									do{
										getmouseclick(WM_MOUSEMOVE, endX, endY);
										delay(0.001);
	//									x<300+10 || x>1600-10 || y<0+10 || y>750-10
									}while(endX<=305 || endX>=1595 || endY>=745 || endY<=5);
									reset_draw_area();
									reset_draw_area_id(map_id);
									drawLine(a, b, endX, endY);
									reDrawWithPID(map_id,pfirst,vfirst);
								}
								if(ismouseclick(WM_LBUTTONDOWN)) {
									id=map_id[endX][endY];
									break;
								}
								delay(1);
							}
							if(id!=pstart.id && id!=-1){
//								clearLine(x,y,endX,endY);
								pend = search_pid(pfirst,id);
								endX = pend.x, endY = pend.y;
//								drawLine(x,y,endX, endY);
								draw_inputVectorBox(map_id,VN);
								if(search_vector_SE_BOOL(vfirst,pstart.id,pend.id)){
								id=search_vectorst_SEtoID(vfirst,pstart.id,pend.id);
								editAction=3;
								}
								else{
								editAction=0;
								}							
							}
							else{
								btn_add_edge(map_id,VN);
								clearLine(a,b,endX,endY);
								reDraw(pfirst,vfirst);
							}
							clearmouseclick(WM_LBUTTONDOWN);
							
						}
						
						if(editAction==2){//xoadinh
							delete_pid(pfirst,vfirst,id);
							reset_map_id(map_id);
							reset_draw_area();
							draw_menu(map_id,pfirst,vfirst,VN);
							reDraw(pfirst,vfirst);
							editAction=0;
						}
						
						if(editAction==3){//thaydoidulieudinh
							findid=id;
							reset_map_id(map_id);
							draw_inputPointBox(map_id,VN);	
						}
						
						if(editAction==5){//dfs
							draw_point_source(search_pid(pfirst,id));
							DFS_Stack(pfirst,vfirst,id);
							DFS_Stack_run(pfirst,vfirst,id);
						}
						
						if(editAction==6){//bfs
							draw_point_source(search_pid(pfirst,id));
							BFS(pfirst,vfirst,id);
							BFS_run(pfirst,vfirst,id);
						}
						
						if(editAction==7){ //chon 2 dinh tim shortest way
							pstart=search_pid(pfirst,id);
							draw_point_source(pstart);
//							a = pstart.x, b = pstart.y; //voi a,b lan luoc la x,y cua dinh bat dau
							int endX, endY;
							while(true){
								if(ismouseclick(WM_LBUTTONDOWN)) {
									getmouseclick(WM_MOUSEMOVE, endX, endY);
									id=map_id[endX][endY];
									break;
								}
								delay(1);
							}
							if(id!=-1 && id<=2000 && id>1000){
//								clearLine(x,y,endX,endY);
								pend = search_pid(pfirst,id);
								draw_point_source(pend);
								reset_draw_area_id(map_id);							
							}
							shortestwayrun(pfirst,vfirst,pstart.id,pend.id,VN);
							editAction=0;
							clearmouseclick(WM_LBUTTONDOWN);
							
						}
						
					}
}				
					
					if(id>2000 && id<9000){//thao tac vs cac canh
						if(editAction==3){ //thay doi du lieu canh
							findid=id;
							reset_map_id(map_id);
							draw_inputVectorBox(map_id,VN);
						}
						
						if(editAction==2){//xoa canh
							delete_vectorID(vfirst,id);
							reset_map_id(map_id);
							reset_draw_area();
							draw_menu(map_id,pfirst,vfirst,VN);
							reDraw(pfirst,vfirst);
							editAction=0;
						}
					}
					
					
					break;
				}
				
			}
			delay(0.001);
		}
	}


