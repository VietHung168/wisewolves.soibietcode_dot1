#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000

//DINH TRU
void BFS_cutvertex(int **a,int *chuaxet,int n,int v){
    int u,dauq=0,cuoiq=0,queue[MAX];
	queue[cuoiq]=v;
    chuaxet[v]=0;
    while(dauq<=cuoiq){
        u=queue[dauq];
        dauq++;
        for(int i=0;i<n;i++){
            if((a[u][i]==1)&&(chuaxet[i]==1)){
                    cuoiq++;
                    queue[cuoiq]=i;
                    chuaxet[i]=0;
                    }
            }
     }
}

int dem(int **a,int *chuaxet,int n){
    int t=0;
    for (int i=0;i<n;i++)
        if(chuaxet[i]){
           BFS_cutvertex(a,chuaxet,n,i);t++;
        }
    return t;
}

int ktdinhtru(int **a,int n,int j){
    int chuaxet[MAX];
    for (int i=0;i<n;i++) chuaxet[i]=TRUE;
    chuaxet[j]=FALSE;
    if (dem(a,chuaxet,n)>1) return TRUE;
    else return FALSE;
}

void timdinhtru(point_node *&pfirst,int **a,int n,bool VN){
	point p;
	point arr[MAX];
	int count=0;
	char tmp[STRMAX]={'\0'};
    for (int i=0;i<n;i++){
    	if(ktdinhtru(a,n,i)==TRUE) {
//       		cout<<i+1<<"  ";
       		p=findPointByOr(pfirst,i+1);
       		arr[count]=p;
       		draw_point_source(p);
       		count++;
	   }
	}
	setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
	if(count==0) {
		if (VN) outtextxy(305,775,"Khong co dinh tru");
		else outtextxy(305,775,"Don't have Cut Vertex");
	}
	else{
		for(int i=0;i<count;i++){
			if(i!=count-1){
			strcat(tmp,arr[i].name);
			strcat(tmp,",");
			}
			else strcat(tmp,arr[i].name);
		}
		outWrapTextXY(305,775,90,20,tmp);
	}
		
}

void cut_vertex(point_node *&pfirst,vector_node *&vfirst,bool VN){
//    cout<<"cac dinh tru la :  ";
	int n=countPoint(pfirst);
	int **a=createMatrix(pfirst,vfirst);		
    timdinhtru(pfirst,a,n,VN);
}
