#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000

//DINH THAT
int **xoaDinh(int **a,int n, int k) {
        // xoa dinh k, n la size cua ma tran, a[][] la ma tran ban dau
        int **arr = new int*[n]; 
        for(int l = 0; l<n; l++)
   			arr[l] = new int[n]; 
		//cap phat dong mang 2 chieu
        for (int i = 0; i <n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == k) {
                    // neu gap dinh k
                    arr[i][j] = arr[j][i] = 0;
                } else {
                    // neu khong gap dinh k
                    arr[i][j] = a[i][j];
                }
            }
        }
        return arr;
}
//bool kiemTraLienThong(int **a,int u,int v,int n) {
//	int chuaxet[n];
//	for(int i=0;i<n;i++) chuaxet[i]=TRUE;
//    int queue[MAX], low = 1, high = 1;
//	queue[low] = u; chuaxet[u] = FALSE;
//	while (low <= high) {
//	u = queue[low]; low = low + 1;
//	for (int i = 0; i < n; i++) {
//		if (a[u][i] && chuaxet[i]) {
//			high = high + 1;
//			queue[high] = i;
//			chuaxet[i] = FALSE;
//                if(i==v){
//                //neu ma xuat hien v thi se co lien thong tu u toi v
//                    return true;
//                }
//            }
//        }
//    }
//    return false;
//} 

bool dfs_find_path(int **a, int n, int start, int end){
	bool chuaxet[n];
	for(int i=0; i<n; i++){
		chuaxet[i]=true;
	}
	int s;
	int Stack[MAX],tmp[MAX], top = 1, t;
	Stack[top] = start; chuaxet[start] = false;
	while (top > 0) {
		s = Stack[top]; top--;
		for (t = 0; t < n; t++) {
			if (chuaxet[t] && a[s][t]!=0) {
				if(t==end) return true;
				chuaxet[t] = FALSE;
				Stack[++top] = s;
				Stack[++top] = t; break;
			}
		}
	}
	return false;
}
       
void mid_vertex(point_node *&pfirst,vector_node *&vfirst,bool VN){
	int **a=createMatrix(pfirst,vfirst);
	int n=countPoint(pfirst);
	point p;
	int u = 0, v = n-1;
	char result[STRMAX]={'\0'};
	point arr[MAX];
	int count=0;
	int **tmp;
        // goi ham xoa dinh va DFS tim duong
    for (int i = 0; i < n; i++) {
        tmp = xoaDinh(a, n, i);
        if (!dfs_find_path(tmp, n, u, v)) {
            if (i != u && i != v) {
//                cout<<"\nDinh that la: "<<i<<endl;
                p=findPointByOr(pfirst,i+1);
                arr[count]=p;
                draw_point_received(p);
                count++;
            }
        }
    }
    setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
	if(count==0) {
		if(VN)	outtextxy(305,775,"Khong co dinh that");
		else 	outtextxy(305,775,"Don't have Mid Vertex");

	}
	else for(int i=0;i<count;i++){
		if(i!=count-1) {
			strcat(result,arr[i].name);
			strcat(result,",");
		}
		else strcat(result,arr[i].name);
	}
	outWrapTextXY(305,795,90,20,result);
}

