#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define STRMAX 4000
#define TRUE 1
#define FALSE 0



//void outvalueRunDFS()

void DFS_Stack_run(point_node *&pfirst,vector_node *&vfirst,int start){
	int n=countPoint(pfirst);
	char a[20],b[20];
	point pstart;
	point pend;
//	point *result=new point[n];
	int s=1;
	int chuaxet[n];
	for(int i=0;i<n;i++){
		chuaxet[i]=TRUE;
	}

	int **matrix=createMatrix(pfirst,vfirst);
	int u=ordinal_Number(pfirst,search_pid(pfirst,start))-1;
	int Stack[MAX], top = 1, t;
	Stack[top] = u; chuaxet[u] = FALSE;
//	result[0]=findPointByOr(pfirst,u+1);
	while (top > 0) {
		s = Stack[top]; top--;
		pstart=findPointByOr(pfirst,s+1);
		 if(pstart.id!=start){
		 	draw_point_wait(pstart);
		 	delay(300);
		 }
		
		for (t = 0; t < n; t++) {
			if (chuaxet[t] && matrix[s][t]!=0) {
//				result[s]=findPointByOr(pfirst,t+1);
//				s++;
				pend=findPointByOr(pfirst,t+1);
//				if(search_vector_SE_BOOL(vfirst,pstart.id,pend.id)){
//					drawLineWithValueRun(pstart.x,pstart.y,pend.x,pend.y,matrix[s][t]);
//					delay(300);
//				}
				draw_point_received(pend);
				chuaxet[t] = FALSE;
				Stack[++top] = s;
				Stack[++top] = t; break;
			}
		}
		delay(300);
	}
}

void DFS_Stack(point_node *&pfirst,vector_node *&vfirst,int start) {
	int n=countPoint(pfirst);
	point *result=new point[n];
	int s;
	int count=1;
	int chuaxet[n];
	for(int i=0;i<n;i++){
		chuaxet[i]=TRUE;
	}

	int **matrix=createMatrix(pfirst,vfirst);
	int u=ordinal_Number(pfirst,search_pid(pfirst,start))-1;
	int Stack[MAX], top = 1, t;
	Stack[top] = u; chuaxet[u] = FALSE;
	result[0]=findPointByOr(pfirst,u+1);
	while (top > 0) {
		s = Stack[top]; top--;
		for (t = 0; t < n; t++) {
			if (chuaxet[t] && matrix[s][t]!=0) {
				result[count]=findPointByOr(pfirst,t+1);
				count++;
				chuaxet[t] = FALSE;
				Stack[++top] = s;
				Stack[++top] = t; break;
			}
		}
	}
	char output[STRMAX]={'\0'};
	for(int i=0;i<count;i++){
		if(i!=count-1){
			strcat(output,result[i].name);
			strcat(output,"-");
		}
		else strcat(output,result[i].name);
	}
	setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
	outWrapTextXY(305,775,90,20,output);
}


void BFS(point_node *&pfirst,vector_node *&vfirst,int start) {
//	int s=0;
	int n=countPoint(pfirst);
	point *result= new point[n];
	int count=0;
	int chuaxet[n];
	for(int i=0;i<n;i++){
		chuaxet[i]=TRUE;
	}
	int **matrix=createMatrix(pfirst,vfirst);
	int u=ordinal_Number(pfirst,search_pid(pfirst,start))-1;
	int queue[MAX], low = 1, high = 1, v;
	queue[low] = u; chuaxet[u] = FALSE;
	while (low <= high) {
		u = queue[low]; low = low + 1;
		result[count]=findPointByOr(pfirst,u+1);
		count++;
		for (v = 0; v < n; v++) {
			if (matrix[u][v]!=0 && chuaxet[v]) {
				high = high + 1;
				queue[high] = v;
				chuaxet[v] = FALSE;
			}
		}
	}
	char output[STRMAX]={'\0'};
	for(int i=0;i<count;i++){
		if(i!=count-1){
			strcat(output,result[i].name);
			strcat(output,"-");
		}
		else strcat(output,result[i].name);
	}
	setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
	outWrapTextXY(305,775,90,20,output);
	}

void BFS_run(point_node *&pfirst,vector_node *&vfirst,int start) {
	int s=0;
	int n=countPoint(pfirst);
//	point p;
//	point *result= new point[n];
	int chuaxet[n];
	for(int i=0;i<n;i++){
		chuaxet[i]=TRUE;
	}
	int **matrix=createMatrix(pfirst,vfirst);
	int u=ordinal_Number(pfirst,search_pid(pfirst,start))-1;
	int queue[MAX], low = 1, high = 1, v;
	queue[low] = u; chuaxet[u] = FALSE;
	while (low <= high) {
		u = queue[low]; low = low + 1;
//		result[s]=findPointByOr(pfirst,u+1);
		draw_point_received(findPointByOr(pfirst,u+1));
		delay(300);
		s++;
				s++;		for (v = 0; v < n; v++) {
			if (matrix[u][v]!=0 && chuaxet[v]) {
				high = high + 1;
				queue[high] = v;
				chuaxet[v] = FALSE;
				draw_point_wait(findPointByOr(pfirst,v+1));
			}
		}
		delay(300);
	}
//	return result;
}
