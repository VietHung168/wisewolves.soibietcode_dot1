#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define TRUE 1
#define FALSE 0

void Result(point_node *&pfirst,int *B,int n,int &d,bool VN){ 
// 	cout<<"Chu trinh Hamilton: ";
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Co chu trinh Hamilton:");
		else 		outtextxy(305,775,"Have Hamilton cycle:");
 		point pstart,pend;
 		point p;
 		char tmp[STRMAX]={'\0'};
 	for(int i=0; i<n; i++){
//		if(i!=0){
//			pstart=findPointByOr(pfirst,B[i]+1);
//			pend=findPointByOr(pfirst,B[i+1]+1);
//			drawLineRun(pstart.x,pstart.y,pend.x,pend.y);	
//			draw_point_received(pstart);
//			draw_point_received(pend);
//		}
//		cout<<B[i]<<" "; 
		p=findPointByOr(pfirst,B[i]+1);
		strcat(tmp,p.name);
		strcat(tmp,"->");
		if(i+1==n){
			p=findPointByOr(pfirst,B[i+1]+1);
			strcat(tmp,p.name);
		}
	}
	outWrapTextXY(305,795,90,20,tmp);
	
	for(int i=0; i<n; i++){
//		if(i!=0){
			pstart=findPointByOr(pfirst,B[i]+1);
			pend=findPointByOr(pfirst,B[i+1]+1);
			drawLineRun(pstart.x,pstart.y,pend.x,pend.y);	
			draw_point_received(pstart);
			draw_point_received(pend);
//		}
		
//		cout<<B[i]<<" "; 
		delay(300);
	}
	d++; 
//	cout<<endl;
} 

void Hamilton(point_node *&pfirst,int **A,int *B, int *C, int i,int n,int &d,bool VN){ 
	std::cout<<std::endl<<"i: "<<i<<std::endl;
	int j, k; 
	for(j=0; j<n; j++){ 
//		std::cout<<"A[B["<<i<<"-1]]["<<j<<"]: "<<A[B[i-1]][j]<<std::endl;
//		std::cout<<"C["<<j<<"]: "<<C[j]<<std::endl;
		if(A[B[i-1]][j]>0 && C[j]==0){ 
			std::cout<<"j: "<<j<<std::endl;
			B[i]=j; C[j]=1; 
			if(i<n) Hamilton(pfirst,A,B, C, i+1,n,d,VN); 
			else
			if(B[i]==B[0]){
//				std::cout<<"Done: "<<std::endl;
				Result(pfirst,B,n,d,VN);
				return; 
			}
			C[j]=0; 
		}		 
	} 
} 

void  Hamilton(point_node *&pfirst, vector_node *&vfirst,bool VN){ 
	int **A=createMatrix(pfirst,vfirst);//gan ma tran ke = A;
	int n= countPoint(pfirst);
	int B[MAX],C[MAX];
	for(int k=0; k<n; k++){
		C[k]=0;
	}
	B[0]=0; 
	int i=1;
	int d=0; 
	Hamilton(pfirst,A,B,C,i,n,d,VN); 
	if(d==0){
//			cout<<"Khong co chu trinh Hamilton"; 
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Khong co chu trinh Hamilton");
		else		outtextxy(305,775,"Don't have Hamilton cycle");
	} 
} 

