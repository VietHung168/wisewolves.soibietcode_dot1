#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000


void dfs_scc(int **a,int *&chuaxet,int n,int u,int *&result,int &count){
	int s;
	int Stack[MAX],tmp[MAX], top = 1, t;
	Stack[top] = u; chuaxet[u] = FALSE;
	while (top > 0) {
		s = Stack[top]; top--;
//		std::cout<<"s: "<<s<<std::endl;
		bool enter = false;
		for (t = 0; t < n; t++) {
//			if(chuaxet[t]==FALSE && a[s][t]!=0) {
//			}
			if (chuaxet[t] && a[s][t]!=0) {
				enter=true;
//				std::cout<<"ke "<<t<<std::endl;
//				system("pause");
				chuaxet[t] = FALSE;
				Stack[++top] = s;
				Stack[++top] = t; break;
			}
		}
		if(!enter){
			result[count]=s;
			count++;
//			std::cout<<"bo "<<s<<"vo stack"<<std::endl;
//			system("pause");
		}
	}
}

void dfs_scc_Reverse(point_node *&pfirst,int **a,int *&chuaxet,int u,int n,int textcolor,int fillcolor,int sidecolor,point **&result,int *&number,int &count){
	number[count]=0;
	int s;
	int Stack[MAX],tmp[MAX], top = 1, t;
	point p;
	Stack[top] = u; chuaxet[u] = FALSE;
	p=findPointByOr(pfirst,u+1);
	result[count][number[count]]=p;
	number[count]++;
	draw_point_groupcolor(p,textcolor,fillcolor,sidecolor);
	while (top > 0) {
		s = Stack[top]; top--;
//		std::cout<<"s: "<<s<<std::endl;
		for (t = 0; t < n; t++) {
			if (chuaxet[t] && a[s][t]!=0) {
//				std::cout<<"ke voi s "<<t<<std::endl;
				chuaxet[t] = FALSE;
				p=findPointByOr(pfirst,t+1);
				result[count][number[count]]=p;
				number[count]++;
				draw_point_groupcolor(p,textcolor,fillcolor,sidecolor);
				Stack[++top] = s;
				Stack[++top] = t; break;
			}
		}
	}
}

void scc(point_node *&pfirst,vector_node *&vfirst,bool VN){
	char output[STRMAX]={'\0'};
	char charnum[3];
	point **result = new point*[countPoint(pfirst)];
	for(int i = 0; i<countPoint(pfirst); i++)
	   result[i] = new point[countPoint(pfirst)];
	int *number= new int [countPoint(pfirst)];
	int count=0;
	int textcolor=0;int fillcolor=0;int sidecolor=5;
	int **a=createMatrix(pfirst,vfirst);
	int n=countPoint(pfirst);
	int **a_Reverse=createMatrix_Reverse(pfirst,vfirst);
	int top=0;
	int *stack=new int[n];
	int *chuaxet=new int[n];
	for(int i=0;i<n;i++) chuaxet[i]=TRUE;
	for(int i=0; i<n ;i++){
		if(chuaxet[i]==TRUE) dfs_scc(a,chuaxet,n,i,stack,top);
	}
//	std::cout<<"stack: "<<endl;
//	for(int i=0; i<n ;i++){
//		std::cout<<findPointByOr(pfirst, stack[i]+1).name<<" "<<endl;
//	}
//	std::cout<<endl;
	for(int i=0;i<n;i++) chuaxet[i]=TRUE;
	for(int i=n-1;i>=0;i--){
//		std::cout<<"dinh "<<stack[i]<<std::endl;
//		system("pause");
		if(chuaxet[stack[i]]==TRUE) {
//			std::cout<<"duyet "<<stack[i]<<std::endl;
//			system("pause");
			if(fillcolor>15) fillcolor=0;
			if(sidecolor>15) sidecolor=0;
			if(fillcolor==textcolor) textcolor=15;
			dfs_scc_Reverse(pfirst,a_Reverse,chuaxet,stack[i],n,textcolor,fillcolor,sidecolor,result,number,count);
			fillcolor++;sidecolor++;textcolor=0;
			count++;
		}
	}
	setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
//	std::cout<<"output: "<<output<<std::endl;
	if(VN) 	strcpy(output,"So thanh phan lien thong: ");
	else	strcpy(output,"Number of connected components: ");
	convertToCharArray(charnum,count);
//	std::cout<<"output: "<<output<<std::endl;
	outtextxy(305,775,strcat(output,charnum));
//	std::cout<<"output: "<<output<<std::endl;
	strcpy(output,"");
	for(int i=0;i<count;i++){
//		std::cout<<"i: "<<i<<std::endl;
//		std::cout<<"number[i]: "<<number[i]<<std::endl;
		for (int j=0;j<number[i];j++){
//			std::cout<<"j: "<<j<<std::endl;
			if(j!=number[i]-1){
				strcat(output,result[i][j].name);
				strcat(output,",");
			}
			else strcat(output,result[i][j].name);
//			std::cout<<"output in for: "<<output<<std::endl;
//			system("pause");
		}
		if(i!=count-1) strcat(output," | ");
	}
//	std::cout<<"output: "<<output<<std::endl;
	outWrapTextXY(305,795,50,20,output);
}

