#pragma once
#include <fstream>
#include "structure.h"
#include "graphic.h"
#include "vectors.h"
#include "points.h"
#include "matrix.h"
using namespace std;


    void clearData(point_node *&pfirst,vector_node *&vfirst){
        point_node *ptmp= pfirst;
        while(ptmp!=NULL){
		    point_node *deleteP = ptmp;
		    ptmp = ptmp->next;
		    delete deleteP;
        }
        vector_node *vtmp= vfirst;
        while(vtmp!=NULL){
            vector_node *deleteV = vtmp;
            vtmp = vtmp->next;
            delete deleteV;
        }
        pfirst=NULL;
        vfirst=NULL;
    }

    void saveGraph(int **matrix,point_node *&pfirst,vector_node *&vfirst,char filename[]){
        strcat(filename,".txt");
        fstream oFile;
        oFile.open(filename,ios::out);
        
        if(oFile==NULL) return;
        
        oFile<<"Vertices:"<<countPoint(pfirst)<<endl;
        point_node *ptmp = pfirst;
        while(ptmp!=NULL){
            oFile<<"Name:"<<ptmp->data.name<<endl;
            oFile<<"x:"<<ptmp->data.x<<endl;
            oFile<<"y:"<<ptmp->data.y<<endl;
            ptmp=ptmp->next;
        }
        oFile<<"Matrix:"<<endl;
        for(int i=0; i<countPoint(pfirst); i++){
            for(int j=0; j<countPoint(pfirst); j++){
                oFile<<matrix[i][j]<<" ";
            }
            oFile<<endl;
	    }
       	oFile.close();
    }

    void openGraph(point_node *&pfirst,vector_node *&vfirst,char filename[]){
        strcat(filename,".txt");
        fstream iFile;
        iFile.open(filename,ios::in);

        if(iFile==NULL) return;
        
        clearData(pfirst,vfirst);
        char text[100]="";
		iFile.getline(text,sizeof(text), '\n');
//      text=text.substr(9);
        strcpy(text,&text[9]);
//        text[strlen(text)]='\0';
        char name[10];
        int x,y;
        int numP = convertToInt(text);
        
        while(countPoint(pfirst)<numP){
			strcpy(text,"");
        	iFile.getline(text,sizeof(text),'\n');
//        	text=text.substr(5);
        	strcpy(text,&text[5]);
//        	text[strlen(text)]='/0';
			strcpy(name,text);
        	strcpy(text,"");
        	iFile.getline(text,sizeof(text),'\n');
//        	text=text.substr(3);
        	strcpy(text,&text[2]);
//        	text[strlen(text)]='/0';
        	x=convertToInt(text);
        	strcpy(text,"");
        	iFile.getline(text,sizeof(text),'\n');
//        	text=text.substr(3);
        	strcpy(text,&text[2]);
//        	text[strlen(text)]='/0';
        	y=convertToInt(text);
        	point p=create_new_point(x,y,name,pfirst);
        	insert_last_p(pfirst,p);	
		}
		
		iFile.getline(text,sizeof(text),'\n');
		point start;
		point end;
		int value;
		point_node *ptmp;
		for(int i=1;i<=numP;i++){
			ptmp=pfirst;
			while(ptmp!=NULL){
				if(ptmp->data.id-1000==i){
					start=ptmp->data;
					break;
				}
				ptmp=ptmp->next;
			}
			for(int j=1;j<=numP;j++){
				strcpy(text,"");
				ptmp=pfirst;
				while(ptmp!=NULL){
					if(ptmp->data.id-1000==j){
						end=ptmp->data;
						break;
					}
					ptmp=ptmp->next;
				}
				iFile.getline(text,sizeof(text),' ');
//				std::cout<<"Matrix:"<<text<<"."<<std::endl;
//				text[strlen(text)]='/0';
				value=convertToInt(text);
				if(value!=0){
					insert_last_v(vfirst, create_new_vector(vfirst,start,end,value));
				}
			}
			iFile.ignore();
		}
		iFile.close();
    }
