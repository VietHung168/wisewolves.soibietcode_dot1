

#define WIDTH 1380
#define HEIGHT 880

#define MAU_TRANG 15
#define MAU_DEN 0
#define MAU_XANH_DUONG 1
#define MAU_VANG 6
#define MAU_XANH_DUONG_NHAT 3
#define MAU_HONG 13
#define MAU_NEN 11
#define MAU_DO_NHAT 12
#define MAU_DO 4
#define MAU_XANH_LA 2



#define STACKSIZE 500

#define TRUE 1
#define FALSE 0

#define MAXLOP 1000
#define MAXMONHOC 300
#define MAXCH 1000
