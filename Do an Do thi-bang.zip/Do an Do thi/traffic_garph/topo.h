#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#include<stack>
#define STRMAX 4000
#define TRUE 1



void push(int vStack[], int &top, int x){
	vStack[++top]=x;
}

int get(int vStack[], int top){
	return vStack[top];
}

int pop(int vStack[], int &top){
	int x = vStack[top--];
	return x;
}

void Init(int tham[], int n){
	for(int i=0; i<n; i++){
		tham[i]=0;
	}
}

//void resetTham(){
//	for(int i=0; i<n; i++){
//		if(tham[i]==1){
//			tham[i]=-1;
//		}
//	}
//}

void DFS(int u, int **a, int tham[], int n, bool &chuTrinh, int vStack[], int &top){
	tham[u]=true;
	for(int v=0; v<n; v++){
		if(a[u][v]>0 && !chuTrinh){
//			cout<<"ke voi "<<u<<"la "<<v<<endl;
//			cout<<"tham "<<v<<": "<<tham[v]<<endl;
			if(tham[v]==0){
				DFS(v, a, tham, n, chuTrinh, vStack, top);
				tham[v]=-1;
			}
			else if(tham[v]==1){
				chuTrinh = true;
				return;
			}
		}
	}
	push(vStack, top, u);
}

//void testTham(){
//	cout<<"Tham: ";
//	for(int i=0; i<n; i++){
//		cout<<tham[i]<<" ";
//	}
//	cout<<endl;
//}

void topoSort(int **a, int tham[], int n, bool &chuTrinh, int vStack[], int &top){
	for(int i=0; i<n; i++){
//		testTham();
		if(tham[i]==0 && !chuTrinh){
//			cout<<"bat dau tham "<<i<<endl;
			DFS(i, a, tham, n, chuTrinh, vStack, top);
			tham[i]=-1;
		}
	}
}

void ketQua(point_node *&pfirst,bool chuTrinh, int vStack[], int &top,bool VN){
	point result[MAX];
	char output[STRMAX]={'\0'};
	int s;
	int count=1;
	point p;
	char num[3];
	if(chuTrinh){
//		cout<<"Khong co topo sorting"<<endl;
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		if(VN) 		outtextxy(305,775,"Khong co sap xep topo");
		else outtextxy(305,775,"Don't have topo sorting");
	}
	else{
		while(top>=0){
			s=pop(vStack, top);
//			cout<<s<<" ";
			p=findPointByOr(pfirst,s+1);
			result[count]=p;
			convertToCharArray(num,count);
			strcpy(p.name,num);
			draw_point_received(p);
			count++;
		}
		for(int i=1;i<count;i++){
		if(i!=count-1){
			strcat(output,result[i].name);
			strcat(output,"-");
		}
		else strcat(output,result[i].name);
	}
		setbkcolor(15);
		setcolor(0);
		settextjustify(0, 2);
		settextstyle(2,0,7);
		outWrapTextXY(305,775,90,20,output);
	}
}

void topo(point_node *&pfirst,vector_node *&vfirst,bool VN){
	int n=countPoint(pfirst);	
	int **a=createMatrix(pfirst,vfirst);
	int tham[MAX];
	
	int vStack[MAX];
	int top=-1;
	
	bool chuTrinh = false;

	Init(tham, n);
	
	topoSort(a, tham, n, chuTrinh, vStack, top);
	
	ketQua(pfirst,chuTrinh, vStack, top,VN);

}
