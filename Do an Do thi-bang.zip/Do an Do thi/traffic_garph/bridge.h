#pragma once
#include "graphic.h"
#include "matrix.h"
#include "points.h"
#include "vectors.h"
#include <iostream>
#include <string.h>
#define MAX 1000
#define TRUE 1
#define FALSE 0
#define STRMAX 4000


void BFS_bridge(int **a,int *chuaxet,int n,int v){
     int u,dauq=0,cuoiq=0,queue[MAX];
     queue[cuoiq]=v;
     chuaxet[v]=0;
     while(dauq<=cuoiq){
            u=queue[dauq];
            dauq++;
            for(int i=0;i<n;i++){
                    if((a[u][i]>=1)&&(chuaxet[i]==TRUE)){
                         cuoiq++;
                         queue[cuoiq]=i;
                         chuaxet[i]=0;
                    }
            }
     }
}

int ktcanhcau(int **a,int n,int u,int v){
	int chuaxet[MAX];
	for(int i=0;i<n;i++) chuaxet[i]=TRUE;
    BFS_bridge(a,chuaxet,n,0);
    for(int i=0;i<n;i++)
    { if(chuaxet[i]) return TRUE;}
    return FALSE;
}
void timcanhcau(point_node *&pfirst,int n,int **a,bool VN){
	int tmp;
	char result[STRMAX];
	point arr[MAX][2];
	int count =0;
	point pstart,pend;
	for (int i=0;i<n;i++){
		 for (int j=0;j<n;j++){
	     	 if(a[i][j]>=1){
            	tmp=a[i][j];
                a[i][j]=0;
                if(ktcanhcau(a,n,i,j)){
//                	cout<<"("<<i+1<<" ,"<<j+1<<") ;  ";
                	pstart=findPointByOr(pfirst,i+1);
                	arr[count][0]=pstart;
                	pend=findPointByOr(pfirst,j+1);
                	arr[count][1]=pend;
                	drawLineRun(pstart.x,pstart.y,pend.x,pend.y);
                	count++;
				}
                a[i][j]=tmp;
            }
		 }
	}
	setbkcolor(15);
	setcolor(0);
	settextjustify(0, 2);
	settextstyle(2,0,7);
	if(count==0) {
		if(VN) outtextxy(305,775,"Khong co canh cau");
		else outtextxy(305,775,"Don't have Bridge");
	}
	else for(int i=0;i<count;i++){
		if(i!=count-1){
			strcat(result,arr[i][0].name);
			strcat(result,"->");
			strcat(result,arr[i][1].name);
			strcat(result," , ");
		}
		else {
			strcat(result,arr[i][0].name);
			strcat(result,"->");
			strcat(result,arr[i][1].name);
		}
	}
	outWrapTextXY(305,775,90,20,result);       
}
void bridge(point_node *&pfirst,vector_node *&vfirst,bool VN){
	int **a=createMatrix(pfirst,vfirst);
	int n= countPoint(pfirst);
	timcanhcau(pfirst,n,a,VN);
}
