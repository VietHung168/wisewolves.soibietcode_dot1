	#pragma once
	
	struct point{
		char name[10];
		int x;
		int y;
		int id;
	};
	
	struct vector{
		point start;
		point end;
		int l;
		int id;
	};
	
	struct point_node{
		point data;
		point_node *next;
	};
	
	struct vector_node{
		vector data;
		vector_node *next;
	};
	
		
	
