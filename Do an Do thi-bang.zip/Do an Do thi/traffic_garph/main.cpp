/* 
graphics in Dev-C++ - nguyenvanquan7826 
*/

#include <winbgim.h>
#include "draw.h"
#include <Windows.h>

void HideConsole()
{
    ::ShowWindow(::GetConsoleWindow(), SW_HIDE);
}


int main(int argc, char *argv[]){	// now, you can run project
	initwindow(1600, 900);			// init window graphics
	setwindowtitle("Graph");
	HideConsole();
//	int map_id[1600][900];			//set map_id for program windows
	int **map_id = new int*[1600];
	for(int i = 0; i<1600; i++)
   	map_id[i] = new int[900];
   	reset_map_id(map_id);
	setbkcolor(11);					// set background
   	cleardevice();
	draw_menu_start(map_id,false);
	run_project(map_id);		
	while(!kbhit()) delay(1);		// pause screen	
	return 0;
}
