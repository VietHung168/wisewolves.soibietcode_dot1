#pragma once
#include "CauHoiThi.h"
using namespace std;

struct BaiThi {
	int soCauHoi;
	char* dapAnDaChon; 
	CauHoiThi* cht; //con tro tro den Cau Hoi thi
};	


